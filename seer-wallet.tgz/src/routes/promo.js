'use strict';

const express = require('express');
const { z } = require('zod');
const { query, withTransaction, newId } = require('../lib/db');
const { toMinor, toDisplay } = require('../lib/money');
const { applyDelta } = require('../lib/ledger');
const { asyncRoute, notFound, unprocessable } = require('../lib/errors');

const router = express.Router();

const validateSchema = z.object({
  code: z.string().min(2).max(64),
  userId: z.string().min(1),
  topupAmount: z.union([z.string(), z.number()]).optional(),
});

const redeemSchema = validateSchema.extend({ walletId: z.string().min(1) });

/**
 * Prices a promo code without changing anything.
 * Throws with the specific reason when the code cannot be used.
 */
async function evaluatePromo({ code, userId, topupAmount }) {
  const found = await query('SELECT * FROM promo_codes WHERE code = $1', [code.toUpperCase()]);
  if (found.rowCount === 0) throw notFound('Promo code not found');
  const promo = found.rows[0];

  const now = new Date();
  if (!promo.is_active) throw unprocessable('Promo code is not active');
  if (promo.starts_at > now) throw unprocessable('Promo code is not yet valid');
  if (promo.expires_at && promo.expires_at < now) throw unprocessable('Promo code has expired');
  if (promo.max_redemptions !== null && promo.used_count >= promo.max_redemptions) {
    throw unprocessable('Promo code has reached its redemption limit');
  }

  const used = await query(
    'SELECT COUNT(*)::int AS n FROM promo_redemptions WHERE promo_code_id = $1 AND user_id = $2',
    [promo.id, userId]
  );
  if (used.rows[0].n >= promo.per_user_limit) {
    throw unprocessable('You have already used this promo code');
  }

  const topupMinor = topupAmount !== undefined ? toMinor(topupAmount) : 0n;
  if (promo.min_topup !== null && topupMinor < promo.min_topup) {
    throw unprocessable(`Minimum top-up for this code is ${toDisplay(promo.min_topup)}`);
  }

  // Integer arithmetic only: a percentage bonus truncates down rather than
  // introducing a fractional qirsh that would have to be rounded somewhere.
  let creditMinor = promo.credit_amount !== null
    ? promo.credit_amount
    : (topupMinor * BigInt(promo.percent_bonus)) / 100n;

  if (promo.max_bonus !== null && creditMinor > promo.max_bonus) creditMinor = promo.max_bonus;
  if (creditMinor <= 0n) throw unprocessable('This code grants no credit for that amount');

  return { promo, creditMinor };
}

// POST /api/promo/validate — dry run
router.post(
  '/validate',
  asyncRoute(async (req, res) => {
    const { promo, creditMinor } = await evaluatePromo(validateSchema.parse(req.body));
    res.json({
      valid: true,
      code: promo.code,
      description: promo.description,
      creditMinor: creditMinor.toString(),
      credit: toDisplay(creditMinor),
      expiresAt: promo.expires_at,
    });
  })
);

// POST /api/promo/redeem
router.post(
  '/redeem',
  asyncRoute(async (req, res) => {
    const body = redeemSchema.parse(req.body);
    const { promo, creditMinor } = await evaluatePromo(body);

    const walletRes = await query('SELECT * FROM wallets WHERE id = $1', [body.walletId]);
    if (walletRes.rowCount === 0) throw notFound('Wallet not found');
    if (walletRes.rows[0].user_id !== body.userId) {
      throw unprocessable('Wallet does not belong to this user');
    }

    const transaction = await withTransaction(async (client) => {
      // The usage counter is claimed with a conditional increment inside the
      // transaction, re-checking the limit against the locked row. Two requests
      // racing for the last remaining use cannot both win — the loser sees
      // zero rows updated and is rejected before any credit is granted.
      const claimed = await client.query(
        `UPDATE promo_codes
            SET used_count = used_count + 1
          WHERE id = $1
            AND is_active = TRUE
            AND (max_redemptions IS NULL OR used_count < max_redemptions)
          RETURNING used_count`,
        [promo.id]
      );
      if (claimed.rowCount === 0) throw unprocessable('Promo code has reached its redemption limit');

      const tx = await applyDelta(client, {
        walletId: body.walletId,
        delta: creditMinor,
        type: 'PROMO_CREDIT',
        description: `Promo ${promo.code}`,
        metadata: { promoCode: promo.code },
      });

      await client.query(
        `INSERT INTO promo_redemptions (id, promo_code_id, user_id, credit_granted, transaction_id)
         VALUES ($1,$2,$3,$4,$5)`,
        [newId('prd'), promo.id, body.userId, creditMinor.toString(), tx.id]
      );

      return tx;
    });

    res.status(201).json({
      redeemed: true,
      code: promo.code,
      creditMinor: creditMinor.toString(),
      credit: toDisplay(creditMinor),
      transactionId: transaction.id,
      balance: toDisplay(transaction.balance_after),
    });
  })
);

module.exports = router;
