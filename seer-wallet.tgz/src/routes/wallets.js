'use strict';

const express = require('express');
const { z } = require('zod');
const { query, newId } = require('../lib/db');
const { toMinor, presentWallet, presentTransaction } = require('../lib/money');
const { credit, debit, transfer } = require('../lib/ledger');
const { asyncRoute, notFound, badRequest } = require('../lib/errors');

const router = express.Router();

const moneyValue = z.union([z.string(), z.number()]);

const createWalletSchema = z.object({
  userId: z.string().min(1),
  currency: z.string().length(3).default('SYR'),
});

const amountSchema = z.object({
  amount: moneyValue,
  description: z.string().max(280).optional(),
  idempotencyKey: z.string().min(8).max(128).optional(),
  provider: z.enum(['STRIPE', 'TELR', 'INTERNAL']).optional(),
  providerRef: z.string().max(200).optional(),
});

const transferSchema = z.object({
  toWalletId: z.string().min(1),
  amount: moneyValue,
  description: z.string().max(280).optional(),
  idempotencyKey: z.string().min(8).max(128).optional(),
});

async function loadWallet(id) {
  const res = await query('SELECT * FROM wallets WHERE id = $1', [id]);
  if (res.rowCount === 0) throw notFound('Wallet not found');
  return res.rows[0];
}

// POST /api/wallets
router.post(
  '/',
  asyncRoute(async (req, res) => {
    const { userId, currency } = createWalletSchema.parse(req.body);

    const user = await query('SELECT id FROM users WHERE id = $1', [userId]);
    if (user.rowCount === 0) throw notFound(`User ${userId} not found`);

    const wallet = await query(
      'INSERT INTO wallets (id, user_id, currency) VALUES ($1,$2,$3) RETURNING *',
      [newId('wlt'), userId, currency.toUpperCase()]
    );

    res.status(201).json({ wallet: presentWallet(wallet.rows[0]) });
  })
);

// GET /api/wallets/:id
router.get(
  '/:id',
  asyncRoute(async (req, res) => {
    res.json({ wallet: presentWallet(await loadWallet(req.params.id)) });
  })
);

// GET /api/wallets/:id/transactions?limit=50&cursor=<createdAt ISO>
router.get(
  '/:id/transactions',
  asyncRoute(async (req, res) => {
    const limit = Math.min(Math.max(Number(req.query.limit) || 50, 1), 200);
    await loadWallet(req.params.id);

    // Keyset pagination on (created_at, id) rather than OFFSET: the page stays
    // correct even as new transactions arrive during paging, and it does not
    // get slower as the ledger grows.
    const cursor = req.query.cursor ? String(req.query.cursor) : null;
    const params = [req.params.id, limit + 1];
    let where = 'wallet_id = $1';
    if (cursor) {
      const [ts, id] = cursor.split('|');
      params.push(ts, id);
      where += ' AND (created_at, id) < ($3::timestamptz, $4)';
    }

    const rows = await query(
      `SELECT * FROM transactions WHERE ${where}
        ORDER BY created_at DESC, id DESC LIMIT $2`,
      params
    );

    const hasMore = rows.rowCount > limit;
    const page = hasMore ? rows.rows.slice(0, limit) : rows.rows;
    const last = page[page.length - 1];

    res.json({
      transactions: page.map(presentTransaction),
      nextCursor: hasMore ? `${last.created_at.toISOString()}|${last.id}` : null,
    });
  })
);

// POST /api/wallets/:id/topup
router.post(
  '/:id/topup',
  asyncRoute(async (req, res) => {
    const body = amountSchema.parse(req.body);

    const { transaction, replayed } = await credit({
      walletId: req.params.id,
      amount: toMinor(body.amount),
      type: 'TOPUP',
      provider: body.provider || 'INTERNAL',
      providerRef: body.providerRef || null,
      idempotencyKey: body.idempotencyKey || null,
      description: body.description || 'Wallet top-up',
    });

    res.status(replayed ? 200 : 201).json({
      replayed,
      transaction: presentTransaction(transaction),
      wallet: presentWallet(await loadWallet(req.params.id)),
    });
  })
);

// POST /api/wallets/:id/withdraw
router.post(
  '/:id/withdraw',
  asyncRoute(async (req, res) => {
    const body = amountSchema.parse(req.body);

    const { transaction, replayed } = await debit({
      walletId: req.params.id,
      amount: toMinor(body.amount),
      type: 'WITHDRAWAL',
      idempotencyKey: body.idempotencyKey || null,
      description: body.description || 'Withdrawal',
    });

    res.status(replayed ? 200 : 201).json({
      replayed,
      transaction: presentTransaction(transaction),
      wallet: presentWallet(await loadWallet(req.params.id)),
    });
  })
);

// POST /api/wallets/:id/transfer
router.post(
  '/:id/transfer',
  asyncRoute(async (req, res) => {
    const body = transferSchema.parse(req.body);
    if (body.toWalletId === req.params.id) throw badRequest('Cannot transfer to the same wallet');

    const { transaction, replayed } = await transfer({
      fromWalletId: req.params.id,
      toWalletId: body.toWalletId,
      amount: toMinor(body.amount),
      description: body.description || 'Transfer',
      idempotencyKey: body.idempotencyKey || null,
    });

    res.status(replayed ? 200 : 201).json({
      replayed,
      transaction: presentTransaction(transaction),
      wallet: presentWallet(await loadWallet(req.params.id)),
    });
  })
);

module.exports = router;
