'use strict';

const express = require('express');
const { z } = require('zod');
const { query, withTransaction, newId } = require('../lib/db');
const { presentWallet, presentUser } = require('../lib/money');
const { asyncRoute, notFound } = require('../lib/errors');

const router = express.Router();

const createUserSchema = z.object({
  phone: z.string().min(6).max(24),
  email: z.string().email().optional(),
  fullName: z.string().max(160).optional(),
  tier: z.enum(['FREE', 'PLUS', 'PRO']).optional(),
});

// POST /api/users — creates the user and their SYR wallet atomically
router.post(
  '/',
  asyncRoute(async (req, res) => {
    const body = createUserSchema.parse(req.body);

    const result = await withTransaction(async (client) => {
      const user = await client.query(
        `INSERT INTO users (id, phone, email, full_name, tier)
         VALUES ($1,$2,$3,$4,$5) RETURNING *`,
        [newId('usr'), body.phone, body.email || null, body.fullName || null, body.tier || 'FREE']
      );

      const wallet = await client.query(
        `INSERT INTO wallets (id, user_id, currency) VALUES ($1,$2,'SYR') RETURNING *`,
        [newId('wlt'), user.rows[0].id]
      );

      return { user: user.rows[0], wallet: wallet.rows[0] };
    });

    res.status(201).json({
      user: presentUser(result.user),
      wallets: [presentWallet(result.wallet)],
    });
  })
);

// GET /api/users/:id
router.get(
  '/:id',
  asyncRoute(async (req, res) => {
    const user = await query('SELECT * FROM users WHERE id = $1', [req.params.id]);
    if (user.rowCount === 0) throw notFound('User not found');

    const wallets = await query(
      'SELECT * FROM wallets WHERE user_id = $1 ORDER BY created_at',
      [req.params.id]
    );

    res.json({
      user: presentUser(user.rows[0]),
      wallets: wallets.rows.map(presentWallet),
    });
  })
);

module.exports = router;
