'use strict';

const express = require('express');
const crypto = require('crypto');
const { query, newId } = require('../lib/db');
const { credit } = require('../lib/ledger');
const { UNIQUE_VIOLATION } = require('../lib/ledger');
const { asyncRoute, unauthorized, badRequest } = require('../lib/errors');

const router = express.Router();

/** Constant-time compare of two hex strings of any length. */
function safeEqual(expected, provided) {
  const a = Buffer.from(expected, 'utf8');
  const b = Buffer.from(provided || '', 'utf8');
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

/**
 * Verifies a Stripe webhook signature without pulling in the Stripe SDK.
 *
 * Stripe sends `Stripe-Signature: t=<unix>,v1=<hex hmac>`, where the signed
 * payload is `<t>.<raw body>`. Two details decide whether this is real security
 * or decoration: the comparison must be constant-time, and the timestamp must be
 * checked against a tolerance window — otherwise a captured request stays valid
 * forever and can simply be replayed.
 */
function verifyStripeSignature(rawBody, header, secret, toleranceSeconds = 300) {
  if (!header) throw unauthorized('Missing Stripe-Signature header');

  const parts = {};
  for (const kv of header.split(',')) {
    const idx = kv.indexOf('=');
    if (idx > 0) parts[kv.slice(0, idx).trim()] = kv.slice(idx + 1).trim();
  }

  const timestamp = Number(parts.t);
  if (!Number.isFinite(timestamp)) throw unauthorized('Malformed Stripe signature');
  if (Math.abs(Date.now() / 1000 - timestamp) > toleranceSeconds) {
    throw unauthorized('Stripe signature timestamp outside tolerance');
  }

  const expected = crypto
    .createHmac('sha256', secret)
    .update(`${timestamp}.${rawBody.toString('utf8')}`, 'utf8')
    .digest('hex');

  if (!safeEqual(expected, parts.v1)) throw unauthorized('Stripe signature mismatch');
  return true;
}

/**
 * Records the event, returning false when this external id was already handled.
 * The unique index on (provider, external_id) is what actually enforces
 * exactly-once delivery: a retried webhook loses the insert race and is skipped,
 * so it can never credit a wallet a second time.
 */
async function claimEvent(provider, externalId, eventType, payload) {
  try {
    await query(
      `INSERT INTO webhook_events (id, provider, external_id, event_type, payload)
       VALUES ($1,$2,$3,$4,$5)`,
      [newId('evt'), provider, externalId, eventType, JSON.stringify(payload)]
    );
    return true;
  } catch (err) {
    if (err && err.code === UNIQUE_VIOLATION) return false;
    throw err;
  }
}

async function markProcessed(provider, externalId) {
  await query(
    'UPDATE webhook_events SET processed_at = NOW() WHERE provider = $1 AND external_id = $2',
    [provider, externalId]
  );
}

// POST /api/webhooks/stripe
router.post(
  '/stripe',
  asyncRoute(async (req, res) => {
    const secret = process.env.STRIPE_WEBHOOK_SECRET;
    if (!secret) throw unauthorized('Stripe webhooks are disabled (STRIPE_WEBHOOK_SECRET not set)');

    verifyStripeSignature(req.body, req.get('stripe-signature'), secret);

    const event = JSON.parse(req.body.toString('utf8'));
    if (!event.id) throw badRequest('Event is missing an id');

    if (!(await claimEvent('STRIPE', event.id, event.type || 'unknown', event))) {
      return res.json({ received: true, duplicate: true });
    }

    if (event.type === 'payment_intent.succeeded') {
      const intent = event.data.object;
      const walletId = intent.metadata && intent.metadata.walletId;
      if (!walletId) throw badRequest('payment_intent is missing metadata.walletId');

      await credit({
        walletId,
        // Stripe already reports the amount in minor units.
        amount: BigInt(intent.amount_received ?? intent.amount),
        type: 'TOPUP',
        provider: 'STRIPE',
        providerRef: intent.id,
        idempotencyKey: `stripe:${intent.id}`,
        description: 'Stripe top-up',
      });
    }

    await markProcessed('STRIPE', event.id);
    res.json({ received: true });
  })
);

// POST /api/webhooks/telr
router.post(
  '/telr',
  asyncRoute(async (req, res) => {
    const secret = process.env.TELR_WEBHOOK_SECRET;
    if (!secret) throw unauthorized('Telr webhooks are disabled (TELR_WEBHOOK_SECRET not set)');

    const expected = crypto
      .createHmac('sha256', secret)
      .update(req.body.toString('utf8'), 'utf8')
      .digest('hex');
    if (!safeEqual(expected, req.get('x-telr-signature'))) {
      throw unauthorized('Telr signature mismatch');
    }

    const event = JSON.parse(req.body.toString('utf8'));
    const ref = event.tranref || event.ref;
    if (!ref) throw badRequest('Telr payload is missing a transaction reference');

    if (!(await claimEvent('TELR', String(ref), String(event.status || 'unknown'), event))) {
      return res.json({ received: true, duplicate: true });
    }

    const status = String(event.status || '').toLowerCase();
    if (status === 'paid' || status === 'a') {
      const walletId = event.cart || (event.metadata && event.metadata.walletId);
      if (!walletId) throw badRequest('Telr payload is missing the wallet reference');

      // Telr reports a decimal amount. Parse it as a string so the conversion to
      // minor units never routes through a binary float.
      const amountStr = String(event.amount).trim();
      if (!/^\d+(\.\d{1,2})?$/.test(amountStr)) throw badRequest(`Invalid Telr amount: ${amountStr}`);
      const [whole, frac = ''] = amountStr.split('.');
      const minor = BigInt(whole) * 100n + BigInt((frac + '00').slice(0, 2));

      await credit({
        walletId,
        amount: minor,
        type: 'TOPUP',
        provider: 'TELR',
        providerRef: String(ref),
        idempotencyKey: `telr:${ref}`,
        description: 'Telr top-up',
      });
    }

    await markProcessed('TELR', String(ref));
    res.json({ received: true });
  })
);

module.exports = { router, verifyStripeSignature, safeEqual };
