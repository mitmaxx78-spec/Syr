'use strict';

const express = require('express');
const { z } = require('zod');
const { query, newId } = require('../lib/db');
const { asyncRoute, notFound } = require('../lib/errors');

const router = express.Router();

// Rates are scaled by 1e8 so no float ever touches the database.
const RATE_SCALE = 100000000n;

const upsertSchema = z.object({
  baseCurrency: z.string().min(3).max(8).optional(),
  quoteCurrency: z.string().min(3).max(8),
  rate: z.union([z.string(), z.number()]),
  source: z.string().max(120).optional(),
});

/** "1234.5678" -> 123456780000n (scaled by 1e8), without floats. */
function scaleRate(value) {
  const str = String(value).trim();
  if (!/^\d+(\.\d{1,8})?$/.test(str)) throw new RangeError(`Invalid rate: ${value}`);
  const [whole, frac = ''] = str.split('.');
  return BigInt(whole) * RATE_SCALE + BigInt((frac + '00000000').slice(0, 8));
}

/** 123456780000n -> "1234.56780000" — string division, never Number(). */
function unscaleRate(scaled) {
  const value = BigInt(scaled);
  const frac = (value % RATE_SCALE).toString().padStart(8, '0');
  return `${value / RATE_SCALE}.${frac}`;
}

function presentRate(row) {
  return {
    baseCurrency: row.base_currency,
    quoteCurrency: row.quote_currency,
    rate: unscaleRate(row.rate_scaled),
    rateScaled: row.rate_scaled.toString(),
    source: row.source,
    fetchedAt: row.fetched_at,
  };
}

// GET /api/rates?base=SYR — newest row per quote currency
router.get(
  '/',
  asyncRoute(async (req, res) => {
    const base = String(req.query.base || 'SYR').toUpperCase();

    // DISTINCT ON picks the newest row per currency in one pass, instead of
    // pulling the whole history back and de-duplicating in JavaScript.
    const rows = await query(
      `SELECT DISTINCT ON (quote_currency) *
         FROM exchange_rates
        WHERE base_currency = $1
        ORDER BY quote_currency, fetched_at DESC`,
      [base]
    );

    res.json({ baseCurrency: base, rates: rows.rows.map(presentRate) });
  })
);

// GET /api/rates/:quote
router.get(
  '/:quote',
  asyncRoute(async (req, res) => {
    const base = String(req.query.base || 'SYR').toUpperCase();
    const quote = req.params.quote.toUpperCase();

    const rows = await query(
      `SELECT * FROM exchange_rates
        WHERE base_currency = $1 AND quote_currency = $2
        ORDER BY fetched_at DESC LIMIT 1`,
      [base, quote]
    );
    if (rows.rowCount === 0) throw notFound(`No rate for ${base}/${quote}`);

    res.json({ rate: presentRate(rows.rows[0]) });
  })
);

// POST /api/rates — append a new observation
router.post(
  '/',
  asyncRoute(async (req, res) => {
    const body = upsertSchema.parse(req.body);

    const row = await query(
      `INSERT INTO exchange_rates (id, base_currency, quote_currency, rate_scaled, source)
       VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [
        newId('rate'),
        (body.baseCurrency || 'SYR').toUpperCase(),
        body.quoteCurrency.toUpperCase(),
        scaleRate(body.rate).toString(),
        body.source || 'manual',
      ]
    );

    res.status(201).json({ rate: presentRate(row.rows[0]) });
  })
);

module.exports = { router, scaleRate, unscaleRate, RATE_SCALE };
