'use strict';

const crypto = require('crypto');
const express = require('express');
const { query } = require('../lib/db');
const { toDisplay } = require('../lib/money');
const { asyncRoute, unauthorized } = require('../lib/errors');

const router = express.Router();

/**
 * Admin routes are gated by a shared secret in ADMIN_API_KEY.
 *
 * An unset secret means the routes refuse everything — it must never fall
 * through to "no auth required". The comparison is timing-safe so the key
 * cannot be recovered byte-by-byte from response latency.
 */
router.use((req, res, next) => {
  const expected = process.env.ADMIN_API_KEY;
  if (!expected) return next(unauthorized('Admin API is disabled (ADMIN_API_KEY not set)'));

  const provided = req.get('x-admin-key') || '';
  const a = Buffer.from(expected, 'utf8');
  const b = Buffer.from(provided, 'utf8');
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return next(unauthorized('Invalid admin key'));
  }
  return next();
});

// GET /api/admin/stats
router.get(
  '/stats',
  asyncRoute(async (req, res) => {
    const [counts, supply, tiers, recent] = await Promise.all([
      query(`SELECT
               (SELECT COUNT(*)::int FROM users) AS users,
               (SELECT COUNT(*)::int FROM wallets) AS wallets,
               (SELECT COUNT(*)::int FROM transactions) AS transactions`),
      query('SELECT COALESCE(SUM(balance), 0)::bigint AS total FROM wallets'),
      query('SELECT tier, COUNT(*)::int AS n FROM users GROUP BY tier'),
      query(`SELECT COUNT(*)::int AS n FROM transactions
              WHERE created_at >= NOW() - INTERVAL '24 hours'`),
    ]);

    const circulating = supply.rows[0].total;

    res.json({
      users: counts.rows[0].users,
      wallets: counts.rows[0].wallets,
      transactions: { total: counts.rows[0].transactions, last24h: recent.rows[0].n },
      circulatingSupply: {
        minor: circulating.toString(),
        display: toDisplay(circulating),
        currency: 'SYR',
      },
      tiers: tiers.rows.map((r) => ({ tier: r.tier, users: r.n })),
      generatedAt: new Date().toISOString(),
    });
  })
);

// GET /api/admin/transactions?limit=100
router.get(
  '/transactions',
  asyncRoute(async (req, res) => {
    const limit = Math.min(Math.max(Number(req.query.limit) || 100, 1), 500);

    const rows = await query(
      `SELECT t.*, w.user_id
         FROM transactions t
         JOIN wallets w ON w.id = t.wallet_id
        ORDER BY t.created_at DESC, t.id DESC
        LIMIT $1`,
      [limit]
    );

    res.json({
      transactions: rows.rows.map((tx) => ({
        id: tx.id,
        walletId: tx.wallet_id,
        userId: tx.user_id,
        type: tx.type,
        status: tx.status,
        amount: toDisplay(tx.amount),
        balanceAfter: toDisplay(tx.balance_after),
        provider: tx.provider,
        createdAt: tx.created_at,
      })),
    });
  })
);

/**
 * GET /api/admin/audit — proves the ledger and the balances agree.
 *
 * Every wallet's balance must equal the sum of its transaction amounts. If a
 * row ever disagrees, money has moved without a ledger entry (or the reverse),
 * which is the one failure mode a wallet system must never hide.
 */
router.get(
  '/audit',
  asyncRoute(async (req, res) => {
    const rows = await query(
      `SELECT w.id AS wallet_id,
              w.balance,
              COALESCE(SUM(t.amount), 0)::bigint AS ledger_sum
         FROM wallets w
         LEFT JOIN transactions t ON t.wallet_id = w.id AND t.status = 'COMPLETED'
        GROUP BY w.id, w.balance
       HAVING w.balance <> COALESCE(SUM(t.amount), 0)::bigint`
    );

    res.json({
      balanced: rows.rowCount === 0,
      discrepancies: rows.rows.map((r) => ({
        walletId: r.wallet_id,
        balance: toDisplay(r.balance),
        ledgerSum: toDisplay(r.ledger_sum),
        differenceMinor: (r.balance - r.ledger_sum).toString(),
      })),
      checkedAt: new Date().toISOString(),
    });
  })
);

module.exports = router;
