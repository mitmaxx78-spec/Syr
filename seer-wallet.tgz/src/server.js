'use strict';

require('dotenv').config();

const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

const { query, close } = require('./lib/db');
const { errorHandler } = require('./lib/errors');

const usersRouter = require('./routes/users');
const walletsRouter = require('./routes/wallets');
const promoRouter = require('./routes/promo');
const { router: ratesRouter } = require('./routes/rates');
const adminRouter = require('./routes/admin');
const { router: webhooksRouter } = require('./routes/webhooks');

const app = express();

// Nginx sits in front, so trust exactly one proxy hop. Without this the rate
// limiter would see Nginx's address for every request and throttle all users
// as if they were one client; trusting *all* proxies would instead let a
// spoofed X-Forwarded-For bypass the limit entirely.
app.set('trust proxy', 1);

app.use(helmet());

// Webhooks must see the exact bytes that were signed, so they mount with a raw
// body parser BEFORE express.json() would consume and re-encode the stream.
app.use('/api/webhooks', express.raw({ type: '*/*', limit: '1mb' }), webhooksRouter);

app.use(express.json({ limit: '256kb' }));

app.use(
  rateLimit({
    windowMs: 60 * 1000,
    limit: Number(process.env.RATE_LIMIT_PER_MINUTE) || 120,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
  })
);

app.get('/health', async (req, res) => {
  try {
    await query('SELECT 1');
    res.json({
      status: 'ok',
      service: 'SEER v2 Wallet',
      database: 'connected',
      time: new Date().toISOString(),
    });
  } catch (err) {
    // A health check that reports "ok" while the database is unreachable is
    // worse than no health check — it hides the outage from every monitor.
    res.status(503).json({
      status: 'degraded',
      service: 'SEER v2 Wallet',
      database: 'unreachable',
      time: new Date().toISOString(),
    });
  }
});

app.use('/api/users', usersRouter);
app.use('/api/wallets', walletsRouter);
app.use('/api/promo', promoRouter);
app.use('/api/rates', ratesRouter);
app.use('/api/admin', adminRouter);

app.use((req, res) => {
  res.status(404).json({
    error: { code: 'NOT_FOUND', message: `No route for ${req.method} ${req.path}` },
  });
});

app.use(errorHandler);

function start(port = Number(process.env.PORT) || 3000) {
  const server = app.listen(port, () => {
    console.log(`[seer] wallet API listening on port ${server.address().port}`);
  });

  // PM2 sends SIGINT on restart. Draining in-flight requests before closing the
  // pool keeps a deploy from cutting a transfer in half.
  async function shutdown(signal) {
    console.log(`[seer] ${signal} received, shutting down`);
    server.close(async () => {
      await close();
      process.exit(0);
    });
    setTimeout(() => process.exit(1), 10000).unref();
  }

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));

  return server;
}

if (require.main === module) start();

module.exports = { app, start };
