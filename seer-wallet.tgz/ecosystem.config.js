module.exports = {
  apps: [
    {
      name: 'seer-api',
      script: 'src/server.js',
      cwd: '/home/seer/app',
      // 2GB / 1 vCPU box: one worker leaves headroom for Postgres itself.
      // Raise this only after the database moves to its own machine.
      instances: 1,
      exec_mode: 'fork',
      autorestart: true,
      max_memory_restart: '400M',
      env: { NODE_ENV: 'production' },
      error_file: '/home/seer/logs/seer-api.err.log',
      out_file: '/home/seer/logs/seer-api.out.log',
      time: true,
    },
    {
      name: 'seer-rates',
      script: 'scripts/update-rates.js',
      cwd: '/home/seer/app',
      // Daily at 03:00 server time. PM2 restarts it on that schedule; the
      // script runs once and exits, so autorestart must stay off.
      cron_restart: '0 3 * * *',
      autorestart: false,
      env: { NODE_ENV: 'production' },
      error_file: '/home/seer/logs/seer-rates.err.log',
      out_file: '/home/seer/logs/seer-rates.out.log',
      time: true,
    },
  ],
};
