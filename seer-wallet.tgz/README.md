# SEER v2 — Syria Coin (SYR) Wallet

Wallet backend for the SEER platform: balances, transfers, top-ups through Stripe
and Telr, promotional codes, and a daily exchange-rate feed.

Node.js 20+, Express, PostgreSQL. No ORM and no build step — plain SQL, so there
is nothing to compile on the server and no engine binary to download at install.

## How money is represented

Every amount is a `BigInt` in the **smallest unit** — 1 SYR = 100 qirsh, so
`10000n` is 100.00 SYR. No float touches a balance anywhere: not in Postgres
(`BIGINT`), not in the driver (the `int8` parser returns `BigInt`), not in JSON
(amounts leave as strings). The API accepts decimal strings like `"12.34"` and
returns both the raw minor-unit value and a formatted string, so a client can
display a balance without ever parsing it into a float.

## What keeps the money correct

| Guarantee | How | Test |
|---|---|---|
| No overdrafts, even concurrently | One `UPDATE ... WHERE balance + delta >= 0 RETURNING balance`. Postgres row-locks for the statement, so the new balance is never computed in JS. | 10 simultaneous debits of 20.00 on a 100.00 balance → exactly 5 succeed |
| No double-spend on retry | `idempotency_key` unique index; a repeat returns the original transaction | 8 concurrent identical top-ups → 1 transaction |
| No double-credited webhooks | Unique `(provider, external_id)`; a retried delivery loses the insert race | Stripe retry → `duplicate: true`, balance unchanged |
| Transfers are all-or-nothing | Both legs in one DB transaction | Failed transfer leaves **both** wallets untouched |
| Forged webhooks rejected | HMAC compared with `timingSafeEqual`, plus a timestamp tolerance window so a captured request cannot be replayed forever | Forged sig → 401; 10-minute-old sig → 401 |
| Ledger is auditable | `balance_after` written in the same transaction; `GET /api/admin/audit` re-derives every balance from its transactions | audit reports `balanced: true` |
| Negative balance impossible | `CHECK (balance >= 0)` in the schema itself | — |

Run them with `npm test` (needs `DATABASE_URL` pointing at a scratch database —
the suite truncates every table).

## Install

```bash
npm install --omit=dev
cp .env.example .env     # fill in ADMIN_API_KEY and the gateway secrets
npm run migrate          # idempotent; safe on every deploy
pm2 start ecosystem.config.js
pm2 save
```

## API

| Method | Path | Purpose |
|---|---|---|
| GET | `/health` | Service and database check |
| POST | `/api/users` | Create a user plus their SYR wallet |
| GET | `/api/users/:id` | User with wallets |
| POST | `/api/wallets` | Add a wallet to an existing user |
| GET | `/api/wallets/:id` | Balance |
| GET | `/api/wallets/:id/transactions` | Paged ledger (keyset cursor) |
| POST | `/api/wallets/:id/topup` | Credit |
| POST | `/api/wallets/:id/withdraw` | Debit |
| POST | `/api/wallets/:id/transfer` | Move funds to another wallet |
| POST | `/api/promo/validate` | Price a promo code, changes nothing |
| POST | `/api/promo/redeem` | Grant the credit |
| GET | `/api/rates` · `/api/rates/:quote` | Latest rates |
| POST | `/api/rates` | Record a rate |
| GET | `/api/admin/stats` | Totals and circulating supply |
| GET | `/api/admin/audit` | Ledger-vs-balance reconciliation |
| POST | `/api/webhooks/stripe` · `/telr` | Payment confirmations |

Admin routes need an `x-admin-key` header matching `ADMIN_API_KEY`. If that
variable is unset the routes reject **everything** — an unset secret never means
"open". Webhook routes stay disabled until their signing secret is set, for the
same reason.

Any call that moves money accepts `idempotencyKey`. Clients on mobile networks
should always send one: it is what makes a retry safe.

## Example

```bash
# Create a user; the response carries the new wallet id
curl -sX POST http://localhost:3000/api/users \
  -H 'content-type: application/json' \
  -d '{"phone":"+963900000000","fullName":"Test User"}'

# Top up 250.00 SYR — safe to repeat
curl -sX POST http://localhost:3000/api/wallets/<WALLET_ID>/topup \
  -H 'content-type: application/json' \
  -d '{"amount":"250.00","idempotencyKey":"demo-topup-0001"}'
```

## Layout

```
db/schema.sql            data model (idempotent DDL)
src/lib/db.js            pool, BigInt type parser, transaction helper
src/lib/money.js         minor-unit conversion and API shaping
src/lib/ledger.js        THE ONLY PLACE A BALANCE CHANGES
src/lib/errors.js        error types and error middleware
src/routes/              HTTP surface
scripts/migrate.js       applies the schema
scripts/update-rates.js  daily rate refresh (PM2 cron)
test/wallet.test.js      19 tests, concurrency included
ecosystem.config.js      PM2 processes
```

If you change how balances move, change `src/lib/ledger.js` and nothing else —
every route goes through it, which is what makes the guarantees above hold.
