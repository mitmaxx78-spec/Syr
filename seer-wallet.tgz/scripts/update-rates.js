'use strict';

/**
 * Daily exchange-rate refresh. PM2 runs this once a day (see ecosystem.config.js).
 *
 * Rates are appended, never overwritten: each fetch is a new row, so the history
 * stays auditable and a bad upstream value can be traced and ignored rather than
 * silently replacing a good one.
 */

require('dotenv').config();

const { query, newId, close } = require('../src/lib/db');
const { scaleRate } = require('../src/routes/rates');

const BASE = (process.env.RATE_BASE || 'SYR').toUpperCase();
const QUOTES = (process.env.RATE_QUOTES || 'USD,EUR,TRY')
  .split(',').map((s) => s.trim().toUpperCase()).filter(Boolean);
const ENDPOINT = process.env.RATE_API_URL || 'https://open.er-api.com/v6/latest';

async function main() {
  const url = `${ENDPOINT}/${BASE}`;
  console.log(`[rates] fetching ${url}`);

  const response = await fetch(url, { signal: AbortSignal.timeout(20000) });
  if (!response.ok) throw new Error(`Rate provider returned ${response.status}`);

  const body = await response.json();
  const rates = body.rates || body.conversion_rates;
  if (!rates) throw new Error('Rate provider response had no rates object');

  let written = 0;
  for (const quote of QUOTES) {
    const value = rates[quote];
    if (value === undefined) {
      console.warn(`[rates] provider did not return ${BASE}/${quote}, skipping`);
      continue;
    }

    await query(
      `INSERT INTO exchange_rates (id, base_currency, quote_currency, rate_scaled, source)
       VALUES ($1,$2,$3,$4,$5)`,
      [newId('rate'), BASE, quote, scaleRate(Number(value).toFixed(8)).toString(), new URL(ENDPOINT).host]
    );
    written += 1;
    console.log(`[rates] ${BASE}/${quote} = ${value}`);
  }

  console.log(`[rates] wrote ${written} of ${QUOTES.length} rates`);
}

main()
  .catch((err) => {
    console.error('[rates] failed:', err.message);
    process.exitCode = 1;
  })
  .finally(close);
