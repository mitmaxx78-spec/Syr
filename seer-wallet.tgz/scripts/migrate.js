'use strict';

/**
 * Applies db/schema.sql. Every statement is CREATE ... IF NOT EXISTS, so this
 * is safe to run on every deploy — it creates what is missing and leaves the
 * rest alone. The whole file runs in one transaction, so a partially applied
 * schema can never be left behind.
 */

require('dotenv').config();

const fs = require('fs');
const path = require('path');
const { withTransaction, close } = require('../src/lib/db');

async function main() {
  const sqlPath = path.join(__dirname, '..', 'db', 'schema.sql');
  const sql = fs.readFileSync(sqlPath, 'utf8');

  await withTransaction(async (client) => {
    await client.query(sql);
  });

  console.log('[migrate] schema applied');
}

main()
  .catch((err) => {
    console.error('[migrate] failed:', err.message);
    process.exitCode = 1;
  })
  .finally(close);
