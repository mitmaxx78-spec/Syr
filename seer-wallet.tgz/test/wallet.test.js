'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');

process.env.ADMIN_API_KEY = process.env.ADMIN_API_KEY || 'test-admin-key';
process.env.STRIPE_WEBHOOK_SECRET = 'whsec_test_secret';

const { app } = require('../src/server');
const { query, close } = require('../src/lib/db');
const { toMinor, toDisplay } = require('../src/lib/money');

let server;
let base;

test.before(async () => {
  server = app.listen(0);
  await new Promise((r) => server.once('listening', r));
  base = `http://127.0.0.1:${server.address().port}`;
  await query('TRUNCATE users, wallets, transactions, promo_codes, promo_redemptions, exchange_rates, webhook_events CASCADE');
});

test.after(async () => {
  await new Promise((r) => server.close(r));
  await close();
});

const api = async (method, path, body, headers = {}) => {
  const res = await fetch(base + path, {
    method,
    headers: { 'content-type': 'application/json', ...headers },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  return { status: res.status, body: await res.json() };
};

const uniquePhone = () => `+9639${crypto.randomInt(10000000, 99999999)}`;

async function makeUser() {
  const res = await api('POST', '/api/users', { phone: uniquePhone(), fullName: 'Test' });
  assert.equal(res.status, 201);
  return { userId: res.body.user.id, walletId: res.body.wallets[0].id };
}

// ---------------------------------------------------------------- money math

test('toMinor/toDisplay round-trip without float error', () => {
  assert.equal(toMinor('12.34'), 1234n);
  assert.equal(toMinor('0.05'), 5n);
  assert.equal(toMinor('1000000'), 100000000n);
  assert.equal(toDisplay(1234n), '12.34');
  assert.equal(toDisplay(5n), '0.05');
  assert.equal(toDisplay(0n), '0.00');

  // 0.1 + 0.2 is the canonical float trap; exact in minor units.
  assert.equal(toMinor('0.10') + toMinor('0.20'), toMinor('0.30'));

  // Beyond Number.MAX_SAFE_INTEGER — a float would round this.
  const huge = '99999999999999999.99';
  assert.equal(toDisplay(toMinor(huge)), huge);
});

test('toMinor rejects malformed input rather than coercing it', () => {
  for (const bad of ['12.345', 'abc', '', '1e5', '12,34', null, undefined, {}]) {
    assert.throws(() => toMinor(bad), RangeError, `should reject ${JSON.stringify(bad)}`);
  }
});

// ---------------------------------------------------------------- core flows

test('health reports database connectivity', async () => {
  const res = await api('GET', '/health');
  assert.equal(res.status, 200);
  assert.equal(res.body.database, 'connected');
});

test('creating a user also creates their SYR wallet at zero', async () => {
  const res = await api('POST', '/api/users', { phone: uniquePhone(), fullName: 'Rex' });
  assert.equal(res.status, 201);
  assert.equal(res.body.wallets.length, 1);
  assert.equal(res.body.wallets[0].balance, '0.00');
  assert.equal(res.body.wallets[0].currency, 'SYR');
});

test('top-up credits the wallet and records balanceAfter', async () => {
  const { walletId } = await makeUser();

  const res = await api('POST', `/api/wallets/${walletId}/topup`, { amount: '250.75' });
  assert.equal(res.status, 201);
  assert.equal(res.body.wallet.balance, '250.75');
  assert.equal(res.body.transaction.balanceAfter, '250.75');
  assert.equal(res.body.transaction.type, 'TOPUP');
});

test('withdrawal debits and cannot overdraw', async () => {
  const { walletId } = await makeUser();
  await api('POST', `/api/wallets/${walletId}/topup`, { amount: '100.00' });

  const ok = await api('POST', `/api/wallets/${walletId}/withdraw`, { amount: '40.00' });
  assert.equal(ok.status, 201);
  assert.equal(ok.body.wallet.balance, '60.00');

  const tooMuch = await api('POST', `/api/wallets/${walletId}/withdraw`, { amount: '60.01' });
  assert.equal(tooMuch.status, 422);
  assert.equal(tooMuch.body.error.message, 'Insufficient funds');

  const after = await api('GET', `/api/wallets/${walletId}`);
  assert.equal(after.body.wallet.balance, '60.00', 'failed debit must not change the balance');
});

test('transfer moves funds atomically between wallets', async () => {
  const a = await makeUser();
  const b = await makeUser();
  await api('POST', `/api/wallets/${a.walletId}/topup`, { amount: '500.00' });

  const res = await api('POST', `/api/wallets/${a.walletId}/transfer`, {
    toWalletId: b.walletId,
    amount: '125.50',
  });
  assert.equal(res.status, 201);

  const from = await api('GET', `/api/wallets/${a.walletId}`);
  const to = await api('GET', `/api/wallets/${b.walletId}`);
  assert.equal(from.body.wallet.balance, '374.50');
  assert.equal(to.body.wallet.balance, '125.50');
});

test('a transfer that would overdraw leaves BOTH wallets untouched', async () => {
  const a = await makeUser();
  const b = await makeUser();
  await api('POST', `/api/wallets/${a.walletId}/topup`, { amount: '10.00' });
  await api('POST', `/api/wallets/${b.walletId}/topup`, { amount: '10.00' });

  const res = await api('POST', `/api/wallets/${a.walletId}/transfer`, {
    toWalletId: b.walletId,
    amount: '999.00',
  });
  assert.equal(res.status, 422);

  const from = await api('GET', `/api/wallets/${a.walletId}`);
  const to = await api('GET', `/api/wallets/${b.walletId}`);
  assert.equal(from.body.wallet.balance, '10.00');
  assert.equal(to.body.wallet.balance, '10.00', 'the credit leg must roll back with the debit leg');
});

// ------------------------------------------------------------- idempotency

test('replaying an idempotency key credits only once', async () => {
  const { walletId } = await makeUser();
  const key = `topup-${crypto.randomUUID()}`;

  const first = await api('POST', `/api/wallets/${walletId}/topup`, { amount: '75.00', idempotencyKey: key });
  const second = await api('POST', `/api/wallets/${walletId}/topup`, { amount: '75.00', idempotencyKey: key });

  assert.equal(first.status, 201);
  assert.equal(second.status, 200);
  assert.equal(second.body.replayed, true);
  assert.equal(second.body.transaction.id, first.body.transaction.id);

  const wallet = await api('GET', `/api/wallets/${walletId}`);
  assert.equal(wallet.body.wallet.balance, '75.00', 'replay must not add a second credit');
});

test('concurrent requests with the same key still credit only once', async () => {
  const { walletId } = await makeUser();
  const key = `race-${crypto.randomUUID()}`;

  // Fired together so they all pass the up-front check and collide on insert.
  const results = await Promise.all(
    Array.from({ length: 8 }, () =>
      api('POST', `/api/wallets/${walletId}/topup`, { amount: '10.00', idempotencyKey: key })
    )
  );

  const ids = new Set(results.map((r) => r.body.transaction.id));
  assert.equal(ids.size, 1, 'all racers must resolve to one transaction');

  const wallet = await api('GET', `/api/wallets/${walletId}`);
  assert.equal(wallet.body.wallet.balance, '10.00');
});

// ------------------------------------------------------------- concurrency

test('concurrent withdrawals cannot overdraw the wallet', async () => {
  const { walletId } = await makeUser();
  await api('POST', `/api/wallets/${walletId}/topup`, { amount: '100.00' });

  // Ten simultaneous debits of 20.00 against a 100.00 balance.
  // Exactly five must succeed; a read-modify-write would let more through.
  const results = await Promise.all(
    Array.from({ length: 10 }, () =>
      api('POST', `/api/wallets/${walletId}/withdraw`, { amount: '20.00' })
    )
  );

  const ok = results.filter((r) => r.status === 201).length;
  const rejected = results.filter((r) => r.status === 422).length;

  assert.equal(ok, 5, `expected exactly 5 successful debits, got ${ok}`);
  assert.equal(rejected, 5);

  const wallet = await api('GET', `/api/wallets/${walletId}`);
  assert.equal(wallet.body.wallet.balance, '0.00');
});

test('ledger sum always equals the stored balance', async () => {
  const { walletId } = await makeUser();
  await api('POST', `/api/wallets/${walletId}/topup`, { amount: '300.00' });
  await api('POST', `/api/wallets/${walletId}/withdraw`, { amount: '45.25' });
  await api('POST', `/api/wallets/${walletId}/topup`, { amount: '10.10' });

  const audit = await api('GET', '/api/admin/audit', undefined, {
    'x-admin-key': process.env.ADMIN_API_KEY,
  });
  assert.equal(audit.status, 200);
  assert.equal(audit.body.balanced, true, JSON.stringify(audit.body.discrepancies));
});

// ------------------------------------------------------------------- promo

test('promo code grants a percentage bonus capped at maxBonus', async () => {
  const { userId, walletId } = await makeUser();
  await query(
    `INSERT INTO promo_codes (id, code, percent_bonus, max_bonus, min_topup, max_redemptions)
     VALUES ('promo_pct','WELCOME10',10,'5000','10000',100)`
  );

  const preview = await api('POST', '/api/promo/validate', {
    code: 'welcome10', userId, topupAmount: '200.00',
  });
  assert.equal(preview.status, 200);
  assert.equal(preview.body.credit, '20.00');

  // 10% of 1000.00 is 100.00, above the 50.00 cap.
  const capped = await api('POST', '/api/promo/validate', {
    code: 'WELCOME10', userId, topupAmount: '1000.00',
  });
  assert.equal(capped.body.credit, '50.00');

  // Below the 100.00 minimum top-up.
  const tooSmall = await api('POST', '/api/promo/validate', {
    code: 'WELCOME10', userId, topupAmount: '50.00',
  });
  assert.equal(tooSmall.status, 422);

  const redeemed = await api('POST', '/api/promo/redeem', {
    code: 'WELCOME10', userId, walletId, topupAmount: '200.00',
  });
  assert.equal(redeemed.status, 201);
  assert.equal(redeemed.body.credit, '20.00');
  assert.equal(redeemed.body.balance, '20.00');
});

test('a promo code cannot be redeemed twice by the same user', async () => {
  const { userId, walletId } = await makeUser();
  await query(
    `INSERT INTO promo_codes (id, code, credit_amount, per_user_limit)
     VALUES ('promo_once','ONCE','2500',1)`
  );

  const first = await api('POST', '/api/promo/redeem', { code: 'ONCE', userId, walletId });
  assert.equal(first.status, 201);
  assert.equal(first.body.credit, '25.00');

  const second = await api('POST', '/api/promo/redeem', { code: 'ONCE', userId, walletId });
  assert.equal(second.status, 422);

  const wallet = await api('GET', `/api/wallets/${walletId}`);
  assert.equal(wallet.body.wallet.balance, '25.00');
});

test('a limited promo code cannot exceed maxRedemptions under a race', async () => {
  await query(
    `INSERT INTO promo_codes (id, code, credit_amount, max_redemptions, per_user_limit)
     VALUES ('promo_ltd','LIMITED3','1000',3,1)`
  );

  const users = await Promise.all(Array.from({ length: 8 }, makeUser));
  const results = await Promise.all(
    users.map((u) => api('POST', '/api/promo/redeem', { code: 'LIMITED3', userId: u.userId, walletId: u.walletId }))
  );

  const granted = results.filter((r) => r.status === 201).length;
  assert.equal(granted, 3, `expected exactly 3 redemptions, got ${granted}`);

  const count = await query(`SELECT used_count FROM promo_codes WHERE id = 'promo_ltd'`);
  assert.equal(count.rows[0].used_count, 3);
});

// ---------------------------------------------------------------- webhooks

function stripeSig(payload, secret, timestamp = Math.floor(Date.now() / 1000)) {
  const sig = crypto.createHmac('sha256', secret).update(`${timestamp}.${payload}`).digest('hex');
  return `t=${timestamp},v1=${sig}`;
}

const postRaw = async (path, payload, headers) => {
  const res = await fetch(base + path, {
    method: 'POST',
    headers: { 'content-type': 'application/json', ...headers },
    body: payload,
  });
  return { status: res.status, body: await res.json() };
};

test('stripe webhook credits the wallet once, rejects bad signatures and replays', async () => {
  const { walletId } = await makeUser();
  const secret = process.env.STRIPE_WEBHOOK_SECRET;

  const payload = JSON.stringify({
    id: `evt_${crypto.randomUUID()}`,
    type: 'payment_intent.succeeded',
    data: { object: { id: `pi_${crypto.randomUUID()}`, amount_received: 45000, metadata: { walletId } } },
  });

  // Forged signature.
  const forged = await postRaw('/api/webhooks/stripe', payload, {
    'stripe-signature': stripeSig(payload, 'wrong_secret'),
  });
  assert.equal(forged.status, 401);

  // Valid signature, but 10 minutes old — replay outside the tolerance window.
  const stale = await postRaw('/api/webhooks/stripe', payload, {
    'stripe-signature': stripeSig(payload, secret, Math.floor(Date.now() / 1000) - 600),
  });
  assert.equal(stale.status, 401);

  const good = await postRaw('/api/webhooks/stripe', payload, {
    'stripe-signature': stripeSig(payload, secret),
  });
  assert.equal(good.status, 200);

  // Stripe retries deliveries; the second must be a no-op.
  const retry = await postRaw('/api/webhooks/stripe', payload, {
    'stripe-signature': stripeSig(payload, secret),
  });
  assert.equal(retry.body.duplicate, true);

  const wallet = await api('GET', `/api/wallets/${walletId}`);
  assert.equal(wallet.body.wallet.balance, '450.00', 'a retried webhook must not credit twice');
});

// ------------------------------------------------------------------- admin

test('admin routes reject a missing or wrong key', async () => {
  assert.equal((await api('GET', '/api/admin/stats')).status, 401);
  assert.equal((await api('GET', '/api/admin/stats', undefined, { 'x-admin-key': 'nope' })).status, 401);

  const ok = await api('GET', '/api/admin/stats', undefined, {
    'x-admin-key': process.env.ADMIN_API_KEY,
  });
  assert.equal(ok.status, 200);
  assert.ok(Number.isInteger(ok.body.users));
  assert.match(ok.body.circulatingSupply.display, /^\d+\.\d{2}$/);
});

// -------------------------------------------------------------------- rates

test('rates are stored and returned without float drift', async () => {
  const posted = await api('POST', '/api/rates', {
    quoteCurrency: 'USD', rate: '0.00007634', source: 'test',
  });
  assert.equal(posted.status, 201);
  assert.equal(posted.body.rate.rate, '0.00007634');

  const fetched = await api('GET', '/api/rates/USD');
  assert.equal(fetched.body.rate.rate, '0.00007634');

  const all = await api('GET', '/api/rates');
  assert.ok(all.body.rates.some((r) => r.quoteCurrency === 'USD'));
});

// -------------------------------------------------------------- validation

test('unknown routes and bad payloads fail cleanly', async () => {
  assert.equal((await api('GET', '/api/nope')).status, 404);
  assert.equal((await api('GET', '/api/wallets/does-not-exist')).status, 404);

  const { walletId } = await makeUser();
  assert.equal((await api('POST', `/api/wallets/${walletId}/topup`, { amount: '-5.00' })).status, 422);
  assert.equal((await api('POST', `/api/wallets/${walletId}/topup`, { amount: 'abc' })).status, 400);
  assert.equal((await api('POST', `/api/wallets/${walletId}/topup`, {})).status, 400);
});
