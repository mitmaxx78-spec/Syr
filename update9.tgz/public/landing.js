'use strict';

/*
 * Customer waiting list. Same shape as join.js but a shorter form: this one is
 * filled in by an ordinary person who arrived from a WhatsApp link, so every
 * extra field is people lost. Area and phone are the only required ones.
 */

// Set this to the WhatsApp number people should reach SEER on, in full
// international form, e.g. '963912345678'. Left empty the contact block stays
// hidden — a dead contact link costs more trust than no contact link.
var WHATSAPP = '';

function $(id) { return document.getElementById(id); }

function radio(name) {
  var picked = document.querySelector('input[name="' + name + '"]:checked');
  return picked ? picked.value : undefined;
}

function markBad(el) {
  el.classList.add('invalid');
  el.addEventListener('input', function once() {
    el.classList.remove('invalid');
    el.removeEventListener('input', once);
  });
}

// Mirrors isCallable() on the server. Kept deliberately loose — it counts
// digits and nothing else, so it can never reject a real number the server
// would have accepted, which is the failure that loses a signup silently.
function digitCount(v) {
  return (v.replace(/[٠-٩۰-۹]/g, '0').match(/\d/g) || []).length;
}

function showContact() {
  if (!WHATSAPP) return;
  var box = $('contact');
  var link = $('waLink');
  if (!box || !link) return;
  link.href = 'https://wa.me/' + WHATSAPP.replace(/\D/g, '');
  box.classList.remove('hidden');
}

showContact();

$('form').addEventListener('submit', function (e) {
  e.preventDefault();

  var btn = $('submitBtn');
  var out = $('msg');
  var area = $('area');
  var phone = $('phone');
  var problem = null;
  var note = '';

  if (area.value.trim().length < 2) {
    problem = area;
    note = 'اكتب منطقتك — مدينة وحي.';
  }

  // Checked after the area so the first empty field is the one focused, but
  // reported with its own message: "رقمك قصير" is recoverable, "ما قدرنا
  // نسجّلك" is not.
  if (digitCount(phone.value) < 9) {
    if (!problem) {
      problem = phone;
      note = phone.value.trim()
        ? 'الرقم ناقص. اكتبه كامل مثل 0912345678.'
        : 'اكتب رقم موبايلك.';
    } else {
      markBad(phone);
    }
  }

  if (problem) {
    markBad(problem);
    out.className = 'msg err';
    out.textContent = note;
    problem.focus();
    problem.scrollIntoView({ behavior: 'smooth', block: 'center' });
    return;
  }

  var payload = {
    phone: phone.value.trim(),
    area: area.value.trim(),
    wants: radio('wants'),
    frequency: radio('frequency'),
    website: $('website').value,
  };

  var name = $('name').value.trim();
  if (name) payload.name = name;

  btn.disabled = true;
  out.className = 'msg ok';
  out.textContent = 'عم نسجّلك…';

  fetch('/api/leads/customer', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(payload),
  })
    .then(function (res) {
      if (res.ok) return null;
      // Read the server's reason before falling back to a generic message, so
      // a rejected phone says which field to fix.
      return res.json().catch(function () { return null; }).then(function (data) {
        var detail = data && data.error && data.error.details;
        if (res.status === 429) {
          throw new Error('في ضغط على التسجيل هلق. جرّب بعد شوي — رقمك ما ضاع.');
        }
        if (detail && detail.field === 'phone') {
          markBad(phone);
          phone.focus();
          throw new Error('الرقم مو مضبوط. اكتبه كامل مثل 0912345678.');
        }
        throw new Error('ما قدرنا نسجّلك. جرّب مرة تانية.');
      });
    })
    .then(function () {
      $('form').classList.add('hidden');
      $('done').classList.remove('hidden');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    })
    .catch(function (err) {
      out.className = 'msg err';
      out.textContent = err.message;
      btn.disabled = false;
    });
});
