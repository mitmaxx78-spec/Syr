'use strict';

/**
 * One-off backfill: rewrites already-stored phone numbers into the canonical
 * form the signup routes now produce, so rows saved before that change are
 * counted with the ones saved after it.
 *
 * Re-running it is harmless — normalising an already-normalised number returns
 * the same string, and those rows are skipped.
 *
 * The waiting list has a UNIQUE (phone) index, so two old rows can collapse
 * onto one number here. That is the point of the exercise, but it means a row
 * has to be dropped, and which one matters: the survivor keeps the earliest
 * created_at and fills any blank field from the row being removed, so no
 * answer is lost and the signup keeps the date the person actually signed up.
 */

require('dotenv').config();

const { withTransaction, close } = require('../src/lib/db');
const { normalizePhone } = require('../src/lib/phone');

async function main() {
  const dryRun = process.argv.includes('--dry-run');
  let changed = 0;
  let merged = 0;

  await withTransaction(async (client) => {
    const { rows } = await client.query(
      `SELECT id, phone, name, area, wants, frequency, created_at
         FROM customer_waitlist ORDER BY created_at ASC`
    );

    // Planned in memory before anything is written, because the two kinds of
    // change collide if they are interleaved. Renaming 0912345678 to its
    // canonical form fails while a second row is still sitting on that exact
    // value under the UNIQUE index — so every duplicate is removed first, and
    // only then are the survivors renamed.
    const groups = new Map();

    for (const row of rows) {
      const canonical = normalizePhone(row.phone);
      if (!canonical) continue;
      if (!groups.has(canonical)) groups.set(canonical, []);
      groups.get(canonical).push(row);
    }

    const renames = [];

    for (const [canonical, group] of groups) {
      // Oldest first from the query, so the first row keeps the signup date.
      const [keeper, ...duplicates] = group;

      for (const dup of duplicates) {
        merged++;
        if (!dryRun) {
          await client.query(
            `UPDATE customer_waitlist SET
               name      = COALESCE(name, $2),
               wants     = COALESCE(wants, $3),
               frequency = COALESCE(frequency, $4),
               area      = COALESCE(NULLIF(area, ''), $5)
             WHERE id = $1`,
            [keeper.id, dup.name, dup.wants, dup.frequency, dup.area]
          );
          await client.query('DELETE FROM customer_waitlist WHERE id = $1', [dup.id]);
        }
      }

      if (keeper.phone !== canonical) renames.push([keeper.id, canonical]);
    }

    for (const [id, canonical] of renames) {
      changed++;
      if (!dryRun) {
        await client.query('UPDATE customer_waitlist SET phone = $1 WHERE id = $2', [
          canonical,
          id,
        ]);
      }
    }

    // Restaurant leads have no unique index, so every row is simply rewritten.
    const leads = await client.query('SELECT id, phone FROM restaurant_leads');
    for (const row of leads.rows) {
      const canonical = normalizePhone(row.phone);
      if (!canonical || canonical === row.phone) continue;
      changed++;
      if (!dryRun) {
        await client.query('UPDATE restaurant_leads SET phone = $1 WHERE id = $2', [
          canonical,
          row.id,
        ]);
      }
    }

    if (dryRun) {
      // Nothing was written, but the transaction is rolled back anyway so a
      // stray query added later cannot leak through a --dry-run.
      throw new DryRun();
    }
  }).catch((err) => {
    if (!(err instanceof DryRun)) throw err;
  });

  console.log(
    `[phones] ${dryRun ? 'would rewrite' : 'rewrote'} ${changed} number(s), ` +
      `${dryRun ? 'would merge' : 'merged'} ${merged} duplicate row(s)`
  );
}

class DryRun extends Error {}

main()
  .catch((err) => {
    console.error('[phones] failed:', err.message);
    process.exitCode = 1;
  })
  .finally(close);
