-- SEER v2 — Syria Coin (SYR) wallet schema
-- All money is BIGINT in the SMALLEST unit (1 SYR = 100 qirsh). Never NUMERIC-as-float.

CREATE TABLE IF NOT EXISTS users (
  id            TEXT PRIMARY KEY,
  phone         TEXT NOT NULL UNIQUE,
  email         TEXT UNIQUE,
  full_name     TEXT,
  tier          TEXT NOT NULL DEFAULT 'FREE'
                CHECK (tier IN ('FREE','PLUS','PRO')),
  is_active     BOOLEAN NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS wallets (
  id            TEXT PRIMARY KEY,
  user_id       TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  currency      TEXT NOT NULL DEFAULT 'SYR',
  -- The database itself refuses a negative balance. Even a bug in application
  -- code cannot write an overdraft past this constraint.
  balance       BIGINT NOT NULL DEFAULT 0 CHECK (balance >= 0),
  status        TEXT NOT NULL DEFAULT 'ACTIVE'
                CHECK (status IN ('ACTIVE','FROZEN','CLOSED')),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (user_id, currency)
);

CREATE INDEX IF NOT EXISTS wallets_user_idx ON wallets(user_id);

CREATE TABLE IF NOT EXISTS transactions (
  id                 TEXT PRIMARY KEY,
  wallet_id          TEXT NOT NULL REFERENCES wallets(id) ON DELETE CASCADE,
  type               TEXT NOT NULL
                     CHECK (type IN ('TOPUP','WITHDRAWAL','TRANSFER_IN','TRANSFER_OUT',
                                     'PAYMENT','REFUND','PROMO_CREDIT','FEE','ADJUSTMENT')),
  status             TEXT NOT NULL DEFAULT 'COMPLETED'
                     CHECK (status IN ('PENDING','COMPLETED','FAILED','REVERSED')),
  -- Signed: positive credits, negative debits.
  amount             BIGINT NOT NULL,
  -- Wallet balance immediately after this row was applied. Written inside the
  -- same transaction as the balance change, so the ledger is self-auditing.
  balance_after      BIGINT NOT NULL,
  currency           TEXT NOT NULL DEFAULT 'SYR',
  provider           TEXT NOT NULL DEFAULT 'INTERNAL'
                     CHECK (provider IN ('STRIPE','TELR','INTERNAL')),
  provider_ref       TEXT,
  -- A repeat of the same key hits this unique index instead of moving money twice.
  idempotency_key    TEXT UNIQUE,
  counterparty_tx_id TEXT,
  description        TEXT,
  metadata           JSONB,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS tx_wallet_created_idx ON transactions(wallet_id, created_at DESC);
CREATE INDEX IF NOT EXISTS tx_provider_ref_idx   ON transactions(provider_ref);

CREATE TABLE IF NOT EXISTS promo_codes (
  id              TEXT PRIMARY KEY,
  code            TEXT NOT NULL UNIQUE,
  description     TEXT,
  credit_amount   BIGINT,
  percent_bonus   INTEGER,
  max_bonus       BIGINT,
  min_topup       BIGINT,
  max_redemptions INTEGER,
  used_count      INTEGER NOT NULL DEFAULT 0,
  per_user_limit  INTEGER NOT NULL DEFAULT 1,
  starts_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at      TIMESTAMPTZ,
  is_active       BOOLEAN NOT NULL DEFAULT TRUE,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  -- A code grants either a fixed credit or a percentage, never both and never neither.
  CHECK ((credit_amount IS NOT NULL) <> (percent_bonus IS NOT NULL))
);

CREATE TABLE IF NOT EXISTS promo_redemptions (
  id             TEXT PRIMARY KEY,
  promo_code_id  TEXT NOT NULL REFERENCES promo_codes(id) ON DELETE CASCADE,
  user_id        TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  credit_granted BIGINT NOT NULL,
  transaction_id TEXT,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS promo_redemptions_user_idx  ON promo_redemptions(user_id);
CREATE INDEX IF NOT EXISTS promo_redemptions_promo_idx ON promo_redemptions(promo_code_id);

CREATE TABLE IF NOT EXISTS exchange_rates (
  id             TEXT PRIMARY KEY,
  base_currency  TEXT NOT NULL DEFAULT 'SYR',
  quote_currency TEXT NOT NULL,
  -- Scaled by 1e8 so no float ever touches a rate.
  rate_scaled    BIGINT NOT NULL,
  source         TEXT,
  fetched_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS rates_pair_idx ON exchange_rates(base_currency, quote_currency, fetched_at DESC);

CREATE TABLE IF NOT EXISTS webhook_events (
  id           TEXT PRIMARY KEY,
  provider     TEXT NOT NULL CHECK (provider IN ('STRIPE','TELR','INTERNAL')),
  external_id  TEXT NOT NULL,
  event_type   TEXT NOT NULL,
  payload      JSONB NOT NULL,
  processed_at TIMESTAMPTZ,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  -- Exactly-once webhook handling: a retried delivery loses this insert race.
  UNIQUE (provider, external_id)
);

-- Restaurant discovery survey.
--
-- Filled in by restaurant owners before any of the platform exists, to find out
-- whether they want it and what they would pay. The questions ask for facts
-- (orders per day, what they use today) rather than opinions, because "would
-- you like a delivery service" is answered yes by everyone and tells you
-- nothing.
CREATE TABLE IF NOT EXISTS restaurant_leads (
  id                TEXT PRIMARY KEY,
  restaurant_name   TEXT NOT NULL,
  contact_name      TEXT NOT NULL,
  phone             TEXT NOT NULL,
  city              TEXT NOT NULL,
  orders_per_day    TEXT,
  order_channel     TEXT,
  delivery_method   TEXT,
  biggest_problem   TEXT,
  would_pay         TEXT,
  ready_to_start    TEXT,
  status            TEXT NOT NULL DEFAULT 'NEW'
                    CHECK (status IN ('NEW','CONTACTED','SIGNED','DECLINED')),
  notes             TEXT,
  -- Kept so obvious duplicate or automated submissions can be spotted later.
  source_ip         TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS leads_created_idx ON restaurant_leads(created_at DESC);
CREATE INDEX IF NOT EXISTS leads_status_idx ON restaurant_leads(status);
