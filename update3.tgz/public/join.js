'use strict';

/*
 * Restaurant survey. Public page, no key, no stored state — it posts once and
 * shows a thank-you. Validation is duplicated on the server; what happens here
 * is only to spare the owner a round trip.
 */

function $(id) { return document.getElementById(id); }

function radio(name) {
  var picked = document.querySelector('input[name="' + name + '"]:checked');
  return picked ? picked.value : undefined;
}

function markBad(el) {
  el.classList.add('invalid');
  el.addEventListener('input', function once() {
    el.classList.remove('invalid');
    el.removeEventListener('input', once);
  });
}

$('form').addEventListener('submit', function (e) {
  e.preventDefault();

  var btn = $('submitBtn');
  var out = $('msg');
  var required = ['restaurantName', 'contactName', 'phone', 'city'];
  var missing = [];

  required.forEach(function (id) {
    var el = $(id);
    if (el.value.trim().length < 2) { markBad(el); missing.push(el); }
  });

  if (missing.length) {
    out.className = 'msg err';
    out.textContent = 'عبّي الخانات المعلّمة بنجمة حمرا.';
    missing[0].focus();
    // Keep the first empty field on screen rather than the error at the bottom.
    missing[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
    return;
  }

  var payload = {
    restaurantName: $('restaurantName').value.trim(),
    contactName: $('contactName').value.trim(),
    phone: $('phone').value.trim(),
    city: $('city').value.trim(),
    ordersPerDay: radio('ordersPerDay'),
    orderChannel: radio('orderChannel'),
    deliveryMethod: radio('deliveryMethod'),
    wouldPay: radio('wouldPay'),
    readyToStart: radio('readyToStart'),
    website: $('website').value,
  };

  var problem = $('biggestProblem').value.trim();
  if (problem) payload.biggestProblem = problem;

  btn.disabled = true;
  out.className = 'msg ok';
  out.textContent = 'عم نبعت…';

  fetch('/api/leads', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(payload),
  })
    .then(function (res) {
      if (res.status === 429) throw new Error('وصلنا طلبات كتير من هالجهاز. جرّب بعد شوي.');
      if (!res.ok) throw new Error('ما قدرنا نبعت الجواب. جرّب مرة تانية.');
      $('form').classList.add('hidden');
      $('done').classList.remove('hidden');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    })
    .catch(function (err) {
      out.className = 'msg err';
      out.textContent = err.message;
      btn.disabled = false;
    });
});
