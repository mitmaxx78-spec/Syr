'use strict';

/*
 * Restaurant survey. Public page, no key, no stored state — it posts once and
 * shows a thank-you. Validation is duplicated on the server; what happens here
 * is only to spare the owner a round trip.
 */

function $(id) { return document.getElementById(id); }

function radio(name) {
  var picked = document.querySelector('input[name="' + name + '"]:checked');
  return picked ? picked.value : undefined;
}

function markBad(el) {
  el.classList.add('invalid');
  el.addEventListener('input', function once() {
    el.classList.remove('invalid');
    el.removeEventListener('input', once);
  });
}

// Mirrors isCallable() on the server. Counts digits only, so it can never
// reject a number the server would have accepted.
function digitCount(v) {
  return (v.replace(/[٠-٩۰-۹]/g, '0').match(/\d/g) || []).length;
}

// A restaurant owner deciding whether to sign up wants to ask a question first
// far more than a customer does, so the contact block matters more here than on
// the landing page. The number comes from the page, set in the admin console.
function showContact() {
  var box = $('contact');
  var link = $('waLink');
  if (!box || !link) return;
  var wa = (box.getAttribute('data-wa') || '').replace(/\D/g, '');
  if (!wa) return;
  link.href = 'https://wa.me/' + wa;
  box.classList.remove('hidden');
}

showContact();

$('form').addEventListener('submit', function (e) {
  e.preventDefault();

  var btn = $('submitBtn');
  var out = $('msg');
  var required = ['restaurantName', 'contactName', 'phone', 'city'];
  var missing = [];

  required.forEach(function (id) {
    var el = $(id);
    if (el.value.trim().length < 2) { markBad(el); missing.push(el); }
  });

  if (missing.length) {
    out.className = 'msg err';
    out.textContent = 'عبّي الخانات المعلّمة بنجمة حمرا.';
    missing[0].focus();
    // Keep the first empty field on screen rather than the error at the bottom.
    missing[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
    return;
  }

  // A filled-in but incomplete number passed the check above and then failed on
  // the server with a message that gave the owner nothing to act on.
  if (digitCount($('phone').value) < 9) {
    markBad($('phone'));
    out.className = 'msg err';
    out.textContent = 'الرقم ناقص. اكتبه كامل مثل 0912345678.';
    $('phone').focus();
    $('phone').scrollIntoView({ behavior: 'smooth', block: 'center' });
    return;
  }

  var payload = {
    restaurantName: $('restaurantName').value.trim(),
    contactName: $('contactName').value.trim(),
    phone: $('phone').value.trim(),
    city: $('city').value.trim(),
    ordersPerDay: radio('ordersPerDay'),
    orderChannel: radio('orderChannel'),
    deliveryMethod: radio('deliveryMethod'),
    wouldPay: radio('wouldPay'),
    readyToStart: radio('readyToStart'),
    website: $('website').value,
  };

  var problem = $('biggestProblem').value.trim();
  if (problem) payload.biggestProblem = problem;

  btn.disabled = true;
  out.className = 'msg ok';
  out.textContent = 'عم نبعت…';

  fetch('/api/leads', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(payload),
  })
    .then(function (res) {
      if (res.ok) return null;
      return res.json().catch(function () { return null; }).then(function (data) {
        var detail = data && data.error && data.error.details;
        if (res.status === 429) {
          throw new Error('في ضغط على التسجيل هلق. جرّب بعد شوي — جوابك ما ضاع.');
        }
        if (detail && detail.field === 'phone') {
          markBad($('phone'));
          $('phone').focus();
          throw new Error('الرقم مو مضبوط. اكتبه كامل مثل 0912345678.');
        }
        throw new Error('ما قدرنا نبعت الجواب. جرّب مرة تانية.');
      });
    })
    .then(function () {
      $('form').classList.add('hidden');
      $('done').classList.remove('hidden');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    })
    .catch(function (err) {
      out.className = 'msg err';
      out.textContent = err.message;
      btn.disabled = false;
    });
});
