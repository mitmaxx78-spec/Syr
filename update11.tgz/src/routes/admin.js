'use strict';

const crypto = require('crypto');
const express = require('express');
const { query } = require('../lib/db');
const { toDisplay } = require('../lib/money');
const { asyncRoute, unauthorized, badRequest } = require('../lib/errors');
const { DEFAULTS, FIELDS, LABELS, TOGGLES } = require('../lib/content');
const { invalidate } = require('../lib/pages');

const router = express.Router();

/**
 * Admin routes are gated by a shared secret in ADMIN_API_KEY.
 *
 * An unset secret means the routes refuse everything — it must never fall
 * through to "no auth required". The comparison is timing-safe so the key
 * cannot be recovered byte-by-byte from response latency.
 */
router.use((req, res, next) => {
  const expected = process.env.ADMIN_API_KEY;
  if (!expected) return next(unauthorized('Admin API is disabled (ADMIN_API_KEY not set)'));

  const provided = req.get('x-admin-key') || '';
  const a = Buffer.from(expected, 'utf8');
  const b = Buffer.from(provided, 'utf8');
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return next(unauthorized('Invalid admin key'));
  }
  return next();
});

// GET /api/admin/stats
router.get(
  '/stats',
  asyncRoute(async (req, res) => {
    const [counts, supply, tiers, recent] = await Promise.all([
      query(`SELECT
               (SELECT COUNT(*)::int FROM users) AS users,
               (SELECT COUNT(*)::int FROM wallets) AS wallets,
               (SELECT COUNT(*)::int FROM transactions) AS transactions`),
      query('SELECT COALESCE(SUM(balance), 0)::bigint AS total FROM wallets'),
      query('SELECT tier, COUNT(*)::int AS n FROM users GROUP BY tier'),
      query(`SELECT COUNT(*)::int AS n FROM transactions
              WHERE created_at >= NOW() - INTERVAL '24 hours'`),
    ]);

    const circulating = supply.rows[0].total;

    res.json({
      users: counts.rows[0].users,
      wallets: counts.rows[0].wallets,
      transactions: { total: counts.rows[0].transactions, last24h: recent.rows[0].n },
      circulatingSupply: {
        minor: circulating.toString(),
        display: toDisplay(circulating),
        currency: 'SYR',
      },
      tiers: tiers.rows.map((r) => ({ tier: r.tier, users: r.n })),
      generatedAt: new Date().toISOString(),
    });
  })
);

// GET /api/admin/transactions?limit=100
router.get(
  '/transactions',
  asyncRoute(async (req, res) => {
    const limit = Math.min(Math.max(Number(req.query.limit) || 100, 1), 500);

    const rows = await query(
      `SELECT t.*, w.user_id
         FROM transactions t
         JOIN wallets w ON w.id = t.wallet_id
        ORDER BY t.created_at DESC, t.id DESC
        LIMIT $1`,
      [limit]
    );

    res.json({
      transactions: rows.rows.map((tx) => ({
        id: tx.id,
        walletId: tx.wallet_id,
        userId: tx.user_id,
        type: tx.type,
        status: tx.status,
        amount: toDisplay(tx.amount),
        balanceAfter: toDisplay(tx.balance_after),
        provider: tx.provider,
        createdAt: tx.created_at,
      })),
    });
  })
);

/**
 * GET /api/admin/audit — proves the ledger and the balances agree.
 *
 * Every wallet's balance must equal the sum of its transaction amounts. If a
 * row ever disagrees, money has moved without a ledger entry (or the reverse),
 * which is the one failure mode a wallet system must never hide.
 */
router.get(
  '/audit',
  asyncRoute(async (req, res) => {
    const rows = await query(
      `SELECT w.id AS wallet_id,
              w.balance,
              COALESCE(SUM(t.amount), 0)::bigint AS ledger_sum
         FROM wallets w
         LEFT JOIN transactions t ON t.wallet_id = w.id AND t.status = 'COMPLETED'
        GROUP BY w.id, w.balance
       HAVING w.balance <> COALESCE(SUM(t.amount), 0)::bigint`
    );

    res.json({
      balanced: rows.rowCount === 0,
      discrepancies: rows.rows.map((r) => ({
        walletId: r.wallet_id,
        balance: toDisplay(r.balance),
        ledgerSum: toDisplay(r.ledger_sum),
        differenceMinor: (r.balance - r.ledger_sum).toString(),
      })),
      checkedAt: new Date().toISOString(),
    });
  })
);

/**
 * GET /api/admin/reconciliation — what is owed versus what was collected.
 *
 * Prepaid credit is a liability, not revenue: every unspent point is a service
 * the operator still has to buy from a driver or a restaurant in real cash. The
 * number that matters is therefore not "money in the bank" but
 *
 *     money in the bank  -  unspent credit outstanding
 *
 * which is the only part that is actually the operator's. When that goes
 * negative, more credit has been issued than was ever collected, and the
 * shortfall is being covered out of the next customer's money. Finding that out
 * at the end of a quarter is how prepaid businesses die, so this endpoint is
 * meant to be read daily against the bank statement.
 *
 * The bank figure cannot be fetched (no bank API), so the caller supplies it as
 * ?bank=<decimal> and the comparison is done here.
 */
router.get(
  '/reconciliation',
  asyncRoute(async (req, res) => {
    const [outstanding, byType] = await Promise.all([
      query('SELECT COALESCE(SUM(balance), 0)::bigint AS total FROM wallets'),
      query(
        `SELECT type, COALESCE(SUM(amount), 0)::bigint AS total, COUNT(*)::int AS n
           FROM transactions
          WHERE status = 'COMPLETED'
          GROUP BY type`
      ),
    ]);

    const totals = {};
    for (const row of byType.rows) totals[row.type] = { minor: row.total, count: row.n };
    const sum = (type) => (totals[type] ? totals[type].minor : 0n);

    // Credits arrive positive, debits negative; negate the debits so both read
    // as "how much moved", not "which direction".
    const issued = sum('TOPUP') + sum('PROMO_CREDIT') + sum('REFUND');
    const spent = -(sum('PAYMENT') + sum('WITHDRAWAL') + sum('FEE'));
    const owed = outstanding.rows[0].total;

    // ?bank= is optional: without it the page still shows what is owed.
    let bank = null;
    let difference = null;
    if (req.query.bank !== undefined && String(req.query.bank).trim() !== '') {
      const raw = String(req.query.bank).trim();
      if (!/^-?\d+(\.\d{1,2})?$/.test(raw)) {
        return res.status(400).json({
          error: { code: 'BAD_REQUEST', message: 'bank must be a decimal amount like 1000.00' },
        });
      }
      const [whole, frac = ''] = raw.replace('-', '').split('.');
      bank = BigInt(whole) * 100n + BigInt(frac.padEnd(2, '0'));
      if (raw.startsWith('-')) bank = -bank;
      difference = bank - owed;
    }

    res.json({
      owed: { minor: owed.toString(), display: toDisplay(owed) },
      issued: { minor: issued.toString(), display: toDisplay(issued) },
      spent: { minor: spent.toString(), display: toDisplay(spent) },
      bank: bank === null ? null : { minor: bank.toString(), display: toDisplay(bank) },
      difference:
        difference === null
          ? null
          : { minor: difference.toString(), display: toDisplay(difference), healthy: difference >= 0n },
      byType: Object.fromEntries(
        Object.entries(totals).map(([k, v]) => [k, { display: toDisplay(v.minor), count: v.count }])
      ),
      checkedAt: new Date().toISOString(),
    });
  })
);

/**
 * GET /api/admin/leads — the survey responses, newest first, plus a tally.
 *
 * The tally is the point. One restaurant saying it would pay proves nothing;
 * what decides whether the business is worth building is the shape of the
 * answers across all of them, especially how many picked "nothing" on price.
 */
router.get(
  '/leads',
  asyncRoute(async (req, res) => {
    const limit = Math.min(Math.max(Number(req.query.limit) || 100, 1), 500);

    const [rows, payTally, readyTally] = await Promise.all([
      query(
        `SELECT * FROM restaurant_leads ORDER BY created_at DESC, id DESC LIMIT $1`,
        [limit]
      ),
      query(
        `SELECT COALESCE(would_pay, 'UNANSWERED') AS k, COUNT(*)::int AS n
           FROM restaurant_leads GROUP BY 1`
      ),
      query(
        `SELECT COALESCE(ready_to_start, 'UNANSWERED') AS k, COUNT(*)::int AS n
           FROM restaurant_leads GROUP BY 1`
      ),
    ]);

    const tally = (r) => Object.fromEntries(r.rows.map((x) => [x.k, x.n]));

    res.json({
      total: rows.rowCount,
      wouldPay: tally(payTally),
      readyToStart: tally(readyTally),
      leads: rows.rows.map((l) => ({
        id: l.id,
        restaurantName: l.restaurant_name,
        contactName: l.contact_name,
        phone: l.phone,
        city: l.city,
        ordersPerDay: l.orders_per_day,
        orderChannel: l.order_channel,
        deliveryMethod: l.delivery_method,
        biggestProblem: l.biggest_problem,
        wouldPay: l.would_pay,
        readyToStart: l.ready_to_start,
        status: l.status,
        createdAt: l.created_at,
      })),
    });
  })
);

/**
 * GET /api/admin/waitlist — how many customers signed up, and where they are.
 *
 * The per-area count is the useful part. A delivery service lives or dies on
 * how long the food takes to arrive, so it has to start in one neighbourhood
 * and saturate it; this says which one, from demand rather than a hunch.
 */
router.get(
  '/waitlist',
  asyncRoute(async (req, res) => {
    const [total, byArea, recent] = await Promise.all([
      query('SELECT COUNT(*)::int AS n FROM customer_waitlist'),
      query(
        `SELECT area, COUNT(*)::int AS n
           FROM customer_waitlist
          GROUP BY area ORDER BY n DESC, area LIMIT 15`
      ),
      query(
        `SELECT COUNT(*)::int AS n FROM customer_waitlist
          WHERE created_at >= NOW() - INTERVAL '24 hours'`
      ),
    ]);

    res.json({
      total: total.rows[0].n,
      last24h: recent.rows[0].n,
      byArea: byArea.rows.map((r) => ({ area: r.area, count: r.n })),
    });
  })
);

/* --------------------------------------------------------------- site content */

// GET /api/admin/content
//
// Returns the form definition together with the current values, so the console
// never has to keep its own copy of the field list. Adding a field to
// content.js makes it appear in the editor with no change here or in the page.
router.get(
  '/content',
  asyncRoute(async (req, res) => {
    const { rows } = await query('SELECT key, value FROM site_content');
    const overrides = Object.fromEntries(rows.map((r) => [r.key, r.value]));

    res.json({
      groups: FIELDS.map((g) => ({
        group: g.group,
        fields: g.keys.map((key) => ({
          key,
          label: LABELS[key] || key,
          toggle: TOGGLES.has(key),
          value: key in overrides ? overrides[key] : DEFAULTS[key],
          isDefault: !(key in overrides),
          default: DEFAULTS[key],
        })),
      })),
    });
  })
);

// PUT /api/admin/content
//
// Takes whatever subset of fields was edited. A value equal to the shipped
// default deletes its row rather than storing a copy, so "never touched" and
// "set back to the original" stay the same state and the table only ever holds
// real decisions.
router.put(
  '/content',
  asyncRoute(async (req, res) => {
    const body = req.body;
    if (!body || typeof body !== 'object' || Array.isArray(body)) {
      throw badRequest('Expected an object of field values');
    }

    const entries = Object.entries(body);
    const unknown = entries.filter(([k]) => !(k in DEFAULTS)).map(([k]) => k);
    if (unknown.length) throw badRequest(`Unknown field(s): ${unknown.join(', ')}`);

    const tooLong = entries.filter(([, v]) => String(v).length > 2000).map(([k]) => k);
    if (tooLong.length) throw badRequest(`Too long: ${tooLong.join(', ')}`);

    for (const [key, raw] of entries) {
      const value = String(raw).trim();
      if (value === String(DEFAULTS[key])) {
        await query('DELETE FROM site_content WHERE key = $1', [key]);
      } else {
        await query(
          `INSERT INTO site_content (key, value) VALUES ($1, $2)
           ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()`,
          [key, value]
        );
      }
    }

    // The rendered pages are cached, so the save is not finished until that
    // cache is dropped — otherwise the console reports success while the site
    // keeps serving the old wording.
    invalidate();

    res.json({ ok: true, saved: entries.length });
  })
);

module.exports = router;
