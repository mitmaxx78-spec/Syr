'use strict';

require('dotenv').config();

const path = require('path');
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

const { query, close } = require('./lib/db');
const { errorHandler } = require('./lib/errors');
const { page, staticPage, PUBLIC_DIR } = require('./lib/pages');

const usersRouter = require('./routes/users');
const leadsRouter = require('./routes/leads');
const walletsRouter = require('./routes/wallets');
const promoRouter = require('./routes/promo');
const { router: ratesRouter } = require('./routes/rates');
const adminRouter = require('./routes/admin');
const { router: webhooksRouter } = require('./routes/webhooks');

const app = express();

// Nginx sits in front, so trust exactly one proxy hop. Without this the rate
// limiter would see Nginx's address for every request and throttle all users
// as if they were one client; trusting *all* proxies would instead let a
// spoofed X-Forwarded-For bypass the limit entirely.
app.set('trust proxy', 1);

app.use(helmet());

// Webhooks must see the exact bytes that were signed, so they mount with a raw
// body parser BEFORE express.json() would consume and re-encode the stream.
app.use('/api/webhooks', express.raw({ type: '*/*', limit: '1mb' }), webhooksRouter);

app.use(express.json({ limit: '256kb' }));

// Scoped to the API rather than the whole app. Mounted globally it also
// counted stylesheet, script and icon requests, so a single page view spent
// four of a visitor's allowance — and behind carrier-grade NAT, where many
// Syrian subscribers share one address, the landing page would start refusing
// to load for everyone on that carrier long before anyone abused anything.
app.use(
  '/api',
  rateLimit({
    windowMs: 60 * 1000,
    limit: Number(process.env.RATE_LIMIT_PER_MINUTE) || 120,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
  })
);

app.get('/health', async (req, res) => {
  try {
    await query('SELECT 1');
    res.json({
      status: 'ok',
      service: 'SEER v2 Wallet',
      database: 'connected',
      time: new Date().toISOString(),
    });
  } catch (err) {
    // A health check that reports "ok" while the database is unreachable is
    // worse than no health check — it hides the outage from every monitor.
    res.status(503).json({
      status: 'degraded',
      service: 'SEER v2 Wallet',
      database: 'unreachable',
      time: new Date().toISOString(),
    });
  }
});

// One page per route, instead of mounting the whole public directory three
// times. The old form let any path resolve under any prefix, so the admin
// console was reachable at /join/admin.html and the landing page at
// /admin/index.html. Nothing was exposed that the root mount did not already
// serve — the admin API stays behind its key — but a console answering from
// the address handed out to restaurant owners is not a boundary worth leaving
// blurred. Pages reference their assets absolutely (/admin.css), so both
// /admin and /admin/ resolve identically.

// Admin console. Deliberately free of inline <script> and style="" so helmet's
// default CSP covers it with no exception carved out. The page holds no secret
// of its own: the admin key is typed in by the operator and kept in their
// browser.
app.get(['/admin', '/admin/'], staticPage('admin.html'));

// The restaurant signup page. Public by design — owners reach it from a link.
app.get(['/join', '/join/'], page('join.html'));

// Required by German law for a commercial site, and by the GDPR for one that
// collects phone numbers. Linked from the footer of every public page.
app.get(['/privacy', '/privacy/'], staticPage('privacy.html'));
app.get(['/impressum', '/impressum/'], staticPage('impressum.html'));

// The landing page, rendered with the editable content applied. Declared here
// so it wins over the static mount below, which would otherwise serve the
// template with its {{markers}} showing.
app.get('/', page('index.html'));

app.use('/api/leads', leadsRouter);
app.use('/api/users', usersRouter);
app.use('/api/wallets', walletsRouter);
app.use('/api/promo', promoRouter);
app.use('/api/rates', ratesRouter);
app.use('/api/admin', adminRouter);

// Each page has exactly one address, set above. Serving the .html files
// directly as well would give every page a second URL that search engines
// index separately and that no page links to.
app.use((req, res, next) => {
  if (req.path.toLowerCase().endsWith('.html')) {
    return res.status(404).json({
      error: { code: 'NOT_FOUND', message: `No route for ${req.method} ${req.path}` },
    });
  }
  next();
});

// Assets. Mounted after the page routes so those keep winning. `index` is off:
// the landing page is rendered above, and serving the raw template here would
// give it a second, unrendered address. Icons are immutable once published, so
// they outlive the short cache the stylesheet needs.
app.use(
  '/',
  express.static(PUBLIC_DIR, {
    index: false,
    maxAge: '5m',
    setHeaders(res, filePath) {
      if (/\.(png|svg|ico|webp|jpg)$/i.test(filePath)) {
        res.setHeader('Cache-Control', 'public, max-age=604800');
      }
    },
  })
);

app.use((req, res) => {
  res.status(404).json({
    error: { code: 'NOT_FOUND', message: `No route for ${req.method} ${req.path}` },
  });
});

app.use(errorHandler);

function start(port = Number(process.env.PORT) || 3000) {
  const server = app.listen(port, () => {
    console.log(`[seer] wallet API listening on port ${server.address().port}`);
  });

  // PM2 sends SIGINT on restart. Draining in-flight requests before closing the
  // pool keeps a deploy from cutting a transfer in half.
  async function shutdown(signal) {
    console.log(`[seer] ${signal} received, shutting down`);
    server.close(async () => {
      await close();
      process.exit(0);
    });
    setTimeout(() => process.exit(1), 10000).unref();
  }

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));

  return server;
}

if (require.main === module) start();

module.exports = { app, start };
