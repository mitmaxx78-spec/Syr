'use strict';

/*
 * SEER wallet admin console.
 *
 * Served from the same origin as the API, so every request is a relative path
 * and there is no CORS surface to widen. The admin key lives in localStorage on
 * this one phone: it is a bearer secret, so the page is only ever served over
 * HTTPS and never logs or displays it after entry.
 */

var KEY_NAME = 'seer.adminKey';
var TYPES = {
  TOPUP: 'تعبئة رصيد',
  PAYMENT: 'دفع خدمة',
  WITHDRAWAL: 'سحب',
  TRANSFER_IN: 'تحويل وارد',
  TRANSFER_OUT: 'تحويل صادر',
  PROMO_CREDIT: 'رصيد ترويجي',
  REFUND: 'استرجاع',
  FEE: 'رسوم',
  ADJUSTMENT: 'تسوية'
};

function $(id) { return document.getElementById(id); }

function store(k, v) {
  // Private browsing and blocked site data both throw here; the console still
  // works for the session, the key just is not remembered.
  try { v === null ? localStorage.removeItem(k) : localStorage.setItem(k, v); } catch (e) { /* ignore */ }
}
function load(k) {
  try { return localStorage.getItem(k); } catch (e) { return null; }
}

function say(el, text, kind) {
  el.className = 'msg ' + (kind || 'ok');
  el.textContent = text;
}
function clear(el) { el.className = ''; el.textContent = ''; }

/*
 * Western digits throughout, on purpose. ar-SY formatting yields Arabic-Indic
 * numerals for the integer part while the API's decimals stay Western, which
 * renders as a mixed-script number like ٣٨٠٫00. Money also gets cross-checked
 * against psql and curl output, and those print Western digits.
 */
var LOCALE = 'en-US';

function num(n) { return Number(n).toLocaleString(LOCALE); }

function money(str) {
  var s = String(str).trim();
  var sign = s.charAt(0) === '-' ? '-' : '';
  if (sign) s = s.slice(1);

  var parts = s.split('.');
  var whole = Number(parts[0] || 0).toLocaleString(LOCALE);
  return sign + whole + '.' + (parts[1] || '00');
}

function when(iso) {
  var d = new Date(iso);
  if (isNaN(d)) return '';
  return d.toLocaleString(LOCALE, {
    month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false
  });
}

/* ---------------------------------------------------------------- network */

function api(path, opts) {
  opts = opts || {};
  var headers = { 'x-admin-key': load(KEY_NAME) || '' };
  if (opts.body) headers['content-type'] = 'application/json';

  return fetch(path, { method: opts.method || 'GET', headers: headers, body: opts.body })
    .then(function (res) {
      return res.json().catch(function () { return {}; }).then(function (data) {
        if (!res.ok) {
          var msg = (data.error && data.error.message) || ('خطأ ' + res.status);
          var err = new Error(msg);
          err.status = res.status;
          throw err;
        }
        return data;
      });
    });
}

/* ------------------------------------------------------------------ views */

function setStatus(kind, text) {
  $('statusDot').className = 'dot ' + kind;
  $('statusText').textContent = text;
}

function renderStats(s) {
  $('mSupply').innerHTML = money(s.circulatingSupply.display) + '<span class="unit">ل.س</span>';
  $('m24h').textContent = num(s.transactions.last24h);
  $('mWallets').textContent = num(s.wallets);
  $('mUsers').textContent = num(s.users);
}

function renderAudit(a) {
  var el = $('auditBanner');
  el.classList.remove('hidden');
  if (a.balanced) {
    el.className = 'banner ok';
    el.textContent = '✓ الدفاتر مضبوطة — كل رصيد بيطابق سجل عملياته';
  } else {
    el.className = 'banner err';
    el.textContent = '⚠ في ' + a.discrepancies.length + ' محفظة رصيدها ما بيطابق السجل — خبّر Claude فوراً';
  }
}

function renderTx(list) {
  var ul = $('txList');
  ul.textContent = '';

  if (!list.length) {
    var empty = document.createElement('li');
    empty.className = 'sub';
    empty.textContent = 'ما في عمليات بعد.';
    ul.appendChild(empty);
    return;
  }

  list.slice(0, 25).forEach(function (t) {
    var li = document.createElement('li');

    var main = document.createElement('div');
    main.className = 'tx-main';

    var type = document.createElement('div');
    type.className = 'tx-type';
    type.textContent = TYPES[t.type] || t.type;

    var meta = document.createElement('div');
    meta.className = 'tx-meta';
    // Only the tail of the wallet id: the full 28 characters push the timestamp
    // off the right edge of a phone, and the tail is enough to tell wallets apart.
    meta.textContent = when(t.createdAt) + ' · …' + String(t.walletId).slice(-8);

    main.appendChild(type);
    main.appendChild(meta);

    var amt = document.createElement('div');
    var negative = String(t.amount).trim().charAt(0) === '-';
    amt.className = 'tx-amt ' + (negative ? 'neg' : 'pos');
    amt.textContent = (negative ? '' : '+') + money(t.amount);

    li.appendChild(main);
    li.appendChild(amt);
    ul.appendChild(li);
  });
}

/* ------------------------------------------------------------------- load */

function renderRecon(r) {
  $('rOwed').textContent = money(r.owed.display);
  $('rIssued').textContent = money(r.issued.display);
  $('rSpent').textContent = money(r.spent.display);

  var out = $('reconMsg');
  if (!r.difference) { clear(out); return; }

  var d = r.difference;
  out.className = 'verdict ' + (d.healthy ? 'ok' : 'bad');
  out.textContent = '';

  // The sign and the digits go in their own isolated run. Concatenating the
  // Arabic unit onto the same string lets the bidi algorithm move a leading
  // "-" to the far end, turning -40,000 into something that reads as 40,000-.
  var big = document.createElement('div');
  big.className = 'big';

  // Named numEl, not num: a local `num` here shadows the global num() helper
  // for the whole function, which is a trap for the next edit.
  var numEl = document.createElement('span');
  numEl.className = 'num';
  numEl.textContent = (d.healthy ? '+' : '') + money(d.display);

  var unit = document.createElement('span');
  unit.className = 'unit';
  unit.textContent = 'ل.س';

  big.appendChild(numEl);
  big.appendChild(unit);

  var note = document.createElement('div');
  note.className = 'note';
  // Deliberately not called "profit": what is left after covering outstanding
  // credit still has to pay the drivers and restaurants for rides already
  // taken. Only the commission on top of that is actually the operator's.
  note.textContent = d.healthy
    ? 'سليم — هاد الباقي بعد تغطية رصيد الزباين. منه بتدفع للسواقين والمطاعم، والعمولة بس إلك.'
    : 'تحذير — أصدرت رصيد أكتر من الفلوس اللي بالبنك. دقّق قبل ما تكمّل.';

  out.appendChild(big);
  out.appendChild(note);
}

var PAY_LABEL = {
  NOTHING: 'ما بدفع', UNDER_100K: 'أقل من 100 ألف', '100K_200K': '100–200 ألف',
  '200K_400K': '200–400 ألف', OVER_400K: 'أكتر من 400 ألف', UNANSWERED: 'ما جاوب'
};
var WANTS_LABEL = {
  RESTAURANTS: 'مطاعم', TAXI: 'تاكسي', MOVING: 'نقل', ALL: 'الكل'
};
var ORDERS_LABEL = {
  NONE: 'ما بوصّل', UNDER_10: 'أقل من 10', '10_30': '10–30',
  '30_70': '30–70', OVER_70: 'أكتر من 70'
};

function renderLeads(d) {
  $('lTotal').textContent = num(d.total);
  $('lReady').textContent = num(d.readyToStart.YES_NOW || 0);

  // Everything except "would pay nothing" and the ones who skipped the question.
  var paying = 0;
  Object.keys(d.wouldPay).forEach(function (k) {
    if (k !== 'NOTHING' && k !== 'UNANSWERED') paying += d.wouldPay[k];
  });
  $('lPaying').textContent = num(paying);

  var ul = $('leadList');
  ul.textContent = '';

  if (!d.leads.length) {
    var empty = document.createElement('li');
    empty.className = 'sub';
    empty.textContent = 'ما عبّى حدا بعد.';
    ul.appendChild(empty);
    return;
  }

  d.leads.slice(0, 20).forEach(function (l) {
    var li = document.createElement('li');

    var main = document.createElement('div');
    main.className = 'tx-main';

    var title = document.createElement('div');
    title.className = 'tx-type';
    title.textContent = l.restaurantName;

    var meta = document.createElement('div');
    meta.className = 'lead-meta';
    var bits = [l.city, l.phone];
    if (l.ordersPerDay) bits.push(ORDERS_LABEL[l.ordersPerDay] + ' طلب/يوم');
    meta.textContent = bits.join(' · ');

    main.appendChild(title);
    main.appendChild(meta);

    if (l.biggestProblem) {
      var prob = document.createElement('div');
      prob.className = 'lead-problem';
      prob.textContent = '«' + l.biggestProblem + '»';
      main.appendChild(prob);
    }

    var tag = document.createElement('div');
    tag.className = 'lead-tag' + (l.wouldPay && l.wouldPay !== 'NOTHING' ? ' pays' : '');
    tag.textContent = PAY_LABEL[l.wouldPay] || '—';

    li.appendChild(main);
    li.appendChild(tag);
    ul.appendChild(li);
  });
}

function renderWaitlist(w) {
  $('wTotal').textContent = num(w.total);
  $('w24h').textContent = num(w.last24h);

  var ul = $('areaList');
  ul.textContent = '';

  if (!w.byArea.length) {
    var empty = document.createElement('li');
    empty.className = 'sub';
    empty.textContent = 'ما سجّل حدا بعد.';
    ul.appendChild(empty);
    return;
  }

  // Bars are relative to the busiest area, not to the total: the question is
  // which neighbourhood leads, not what share of everything it holds.
  var top = w.byArea[0].count || 1;

  w.byArea.forEach(function (a, i) {
    var li = document.createElement('li');
    li.className = 'area-row';

    var label = document.createElement('div');
    label.className = 'area-name' + (i === 0 ? ' first' : '');
    label.textContent = a.area;

    var bar = document.createElement('div');
    bar.className = 'area-bar';
    var fill = document.createElement('span');
    fill.style.width = Math.max(4, Math.round((a.count / top) * 100)) + '%';
    bar.appendChild(fill);

    var n = document.createElement('div');
    n.className = 'area-count';
    n.textContent = num(a.count);

    label.appendChild(bar);
    li.appendChild(label);
    li.appendChild(n);
    ul.appendChild(li);
  });
}

function refresh(bank) {
  setStatus('', 'جاري التحديث…');

  var reconUrl = '/api/admin/reconciliation';
  if (bank) reconUrl += '?bank=' + encodeURIComponent(bank);

  return Promise.all([
    api('/api/admin/stats'),
    api('/api/admin/audit'),
    api('/api/admin/transactions?limit=25'),
    api(reconUrl),
    api('/api/admin/leads?limit=20'),
    api('/api/admin/waitlist')
  ]).then(function (r) {
    renderStats(r[0]);
    renderAudit(r[1]);
    renderTx(r[2].transactions);
    renderRecon(r[3]);
    renderLeads(r[4]);
    renderWaitlist(r[5]);
    setStatus('ok', 'متصل');
  }).catch(function (err) {
    if (err.status === 401) {
      // A stale or wrong key should send us back to the gate, not sit on a
      // dashboard full of dashes with no explanation.
      store(KEY_NAME, null);
      showGate('المفتاح غلط أو انتهى. جرّب من جديد.');
      return;
    }
    setStatus('err', 'ما وصلت للسيرفر');
  });
}

function showGate(message) {
  $('panel').classList.add('hidden');
  $('gate').classList.remove('hidden');
  setStatus('err', 'مو داخل');
  if (message) say($('gateMsg'), message, 'err');
}

function showPanel() {
  $('gate').classList.add('hidden');
  $('panel').classList.remove('hidden');
  refresh();
}

/* ----------------------------------------------------------------- events */

$('keySave').addEventListener('click', function () {
  var v = $('keyInput').value.trim();
  if (!v) return say($('gateMsg'), 'اكتب المفتاح أول.', 'err');
  store(KEY_NAME, v);
  $('keyInput').value = '';
  clear($('gateMsg'));
  showPanel();
});

$('keyInput').addEventListener('keydown', function (e) {
  if (e.key === 'Enter') $('keySave').click();
});

$('refreshBtn').addEventListener('click', function () { refresh($('bankAmt').value.trim()); });

$('reconBtn').addEventListener('click', function () {
  var v = $('bankAmt').value.trim();
  if (!v) return say($('reconMsg'), 'اكتب كم بحسابك البنكي.', 'err');
  if (!/^-?\d+(\.\d{1,2})?$/.test(v)) {
    return say($('reconMsg'), 'اكتب رقم فقط، مثلاً 1000000 أو 1000000.50', 'err');
  }
  refresh(v);
});

$('bankAmt').addEventListener('keydown', function (e) {
  if (e.key === 'Enter') $('reconBtn').click();
});

$('logoutBtn').addEventListener('click', function () {
  store(KEY_NAME, null);
  showGate('انمسح المفتاح من هالتلفون.');
});

$('lookupBtn').addEventListener('click', function () {
  var id = $('wid').value.trim();
  var out = $('lookupMsg');
  if (!id) return say(out, 'اكتب رقم المحفظة.', 'err');

  say(out, 'جاري البحث…', 'ok');
  api('/api/wallets/' + encodeURIComponent(id))
    .then(function (w) {
      say(out, 'الرصيد: ' + money(w.balance) + ' ل.س · الحالة: ' + w.status, 'ok');
    })
    .catch(function (e) { say(out, e.message, 'err'); });
});

$('topBtn').addEventListener('click', function () {
  var id = $('wid').value.trim();
  var amount = $('topAmt').value.trim();
  var out = $('topMsg');
  var btn = $('topBtn');

  if (!id) return say(out, 'اكتب رقم المحفظة بخانة البحث فوق.', 'err');
  if (!amount) return say(out, 'اكتب المبلغ.', 'err');

  // A fresh key per click: a double-tap sends two different keys and would top
  // up twice, so the key is tied to this click, not to the amount.
  var idem = 'admin-' + Date.now() + '-' + Math.random().toString(16).slice(2, 8);

  btn.disabled = true;
  say(out, 'جاري التعبئة…', 'ok');

  api('/api/wallets/' + encodeURIComponent(id) + '/topup', {
    method: 'POST',
    body: JSON.stringify({ amount: amount, idempotencyKey: idem, description: 'تعبئة من لوحة التحكم' })
  })
    .then(function (r) {
      say(out, 'تمت التعبئة ✓ الرصيد الجديد: ' + money(r.wallet.balance) + ' ل.س', 'ok');
      $('topAmt').value = '';
      return refresh();
    })
    .catch(function (e) { say(out, e.message, 'err'); })
    .then(function () { btn.disabled = false; });
});

/* ------------------------------------------------------------------- boot */

if (load(KEY_NAME)) showPanel();
else showGate();
