'use strict';

/*
 * Customer waiting list. Same shape as join.js but a shorter form: this one is
 * filled in by an ordinary person who arrived from a WhatsApp link, so every
 * extra field is people lost. Area and phone are the only required ones.
 */

function $(id) { return document.getElementById(id); }

function radio(name) {
  var picked = document.querySelector('input[name="' + name + '"]:checked');
  return picked ? picked.value : undefined;
}

function markBad(el) {
  el.classList.add('invalid');
  el.addEventListener('input', function once() {
    el.classList.remove('invalid');
    el.removeEventListener('input', once);
  });
}

$('form').addEventListener('submit', function (e) {
  e.preventDefault();

  var btn = $('submitBtn');
  var out = $('msg');
  var missing = [];

  ['area', 'phone'].forEach(function (id) {
    var el = $(id);
    if (el.value.trim().length < 2) { markBad(el); missing.push(el); }
  });

  if (missing.length) {
    out.className = 'msg err';
    out.textContent = 'عبّي منطقتك ورقمك.';
    missing[0].focus();
    missing[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
    return;
  }

  var payload = {
    phone: $('phone').value.trim(),
    area: $('area').value.trim(),
    wants: radio('wants'),
    frequency: radio('frequency'),
    website: $('website').value,
  };

  var name = $('name').value.trim();
  if (name) payload.name = name;

  btn.disabled = true;
  out.className = 'msg ok';
  out.textContent = 'عم نسجّلك…';

  fetch('/api/leads/customer', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(payload),
  })
    .then(function (res) {
      if (res.status === 429) throw new Error('وصلنا تسجيلات كتير من هالجهاز. جرّب بعد شوي.');
      if (!res.ok) throw new Error('ما قدرنا نسجّلك. جرّب مرة تانية.');
      $('form').classList.add('hidden');
      $('done').classList.remove('hidden');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    })
    .catch(function (err) {
      out.className = 'msg err';
      out.textContent = err.message;
      btn.disabled = false;
    });
});
