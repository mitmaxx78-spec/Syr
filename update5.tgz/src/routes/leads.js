'use strict';

/**
 * Public restaurant survey intake.
 *
 * This is the only unauthenticated write endpoint in the service, so it is
 * deliberately narrow: a fixed set of short fields, a strict allow-list on
 * every multiple-choice answer, its own rate limit, and a honeypot. Nothing
 * here touches money or any other table.
 */

const express = require('express');
const rateLimit = require('express-rate-limit');
const { z } = require('zod');
const { query, newId } = require('../lib/db');
const { asyncRoute, badRequest } = require('../lib/errors');

const router = express.Router();

// Allow-lists rather than free text, so a stray value can never reach a report
// and the answers stay countable.
const ORDERS = ['NONE', 'UNDER_10', '10_30', '30_70', 'OVER_70'];
const CHANNEL = ['PHONE', 'WHATSAPP', 'OTHER_APP', 'WALK_IN_ONLY'];
const DELIVERY = ['OWN_DRIVERS', 'EXTERNAL_DRIVERS', 'NO_DELIVERY'];
const WOULD_PAY = ['NOTHING', 'UNDER_100K', '100K_200K', '200K_400K', 'OVER_400K'];
const READY = ['YES_NOW', 'THINKING', 'NO'];

const leadSchema = z.object({
  restaurantName: z.string().trim().min(2).max(120),
  contactName: z.string().trim().min(2).max(120),
  phone: z.string().trim().min(6).max(30),
  city: z.string().trim().min(2).max(120),
  ordersPerDay: z.enum(ORDERS).optional(),
  orderChannel: z.enum(CHANNEL).optional(),
  deliveryMethod: z.enum(DELIVERY).optional(),
  biggestProblem: z.string().trim().max(1000).optional(),
  wouldPay: z.enum(WOULD_PAY).optional(),
  readyToStart: z.enum(READY).optional(),
  // Honeypot: a real person never sees this field, so anything in it is a bot.
  // It has to pass validation — rejecting it with a 400 tells the bot which
  // field gave it away, and it simply retries without that one. Accept it,
  // then drop the submission below while answering 201.
  website: z.string().max(500).optional(),
});

// Tighter than the global limiter: a restaurant owner submits once, a script
// submits thousands.
const submitLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  limit: 10,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: { error: { code: 'RATE_LIMITED', message: 'Too many submissions, try again later' } },
});

router.post(
  '/',
  submitLimiter,
  asyncRoute(async (req, res) => {
    const body = leadSchema.parse(req.body);

    // Answer the bot exactly as it expects, so it does not retry with a variant.
    if (body.website) return res.status(201).json({ ok: true });

    const id = newId('lead');
    await query(
      `INSERT INTO restaurant_leads
         (id, restaurant_name, contact_name, phone, city, orders_per_day,
          order_channel, delivery_method, biggest_problem, would_pay,
          ready_to_start, source_ip)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
      [
        id,
        body.restaurantName,
        body.contactName,
        body.phone,
        body.city,
        body.ordersPerDay || null,
        body.orderChannel || null,
        body.deliveryMethod || null,
        body.biggestProblem || null,
        body.wouldPay || null,
        body.readyToStart || null,
        req.ip || null,
      ]
    );

    // Nothing about the stored record is echoed back: the response is public.
    res.status(201).json({ ok: true });
  })
);

/* ------------------------------------------------------ customer waiting list */

const WANTS = ['FOOD', 'GROCERY', 'RIDES', 'ALL'];
const FREQUENCY = ['NEVER', 'RARELY', 'WEEKLY', 'SEVERAL_WEEKLY', 'DAILY'];

const waitlistSchema = z.object({
  name: z.string().trim().max(120).optional(),
  phone: z.string().trim().min(6).max(30),
  area: z.string().trim().min(2).max(120),
  wants: z.enum(WANTS).optional(),
  frequency: z.enum(FREQUENCY).optional(),
  website: z.string().max(500).optional(),
});

router.post(
  '/customer',
  submitLimiter,
  asyncRoute(async (req, res) => {
    const body = waitlistSchema.parse(req.body);
    if (body.website) return res.status(201).json({ ok: true });

    // ON CONFLICT rather than an error: someone re-submitting their own number
    // has done nothing wrong, and a failure screen would just lose them.
    await query(
      `INSERT INTO customer_waitlist (id, name, phone, area, wants, frequency, source_ip)
       VALUES ($1,$2,$3,$4,$5,$6,$7)
       ON CONFLICT (phone) DO UPDATE
         SET area = EXCLUDED.area,
             wants = COALESCE(EXCLUDED.wants, customer_waitlist.wants),
             frequency = COALESCE(EXCLUDED.frequency, customer_waitlist.frequency),
             name = COALESCE(EXCLUDED.name, customer_waitlist.name)`,
      [
        newId('wait'),
        body.name || null,
        body.phone,
        body.area,
        body.wants || null,
        body.frequency || null,
        req.ip || null,
      ]
    );

    res.status(201).json({ ok: true });
  })
);

router.all('/', (req, res, next) => next(badRequest('Only POST is supported here')));

module.exports = router;
